-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 24 Jul 2020 pada 05.06
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ikades`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(100) NOT NULL,
  `username_admin` varchar(30) NOT NULL,
  `password_admin` varchar(30) NOT NULL,
  `foto_admin` varchar(300) NOT NULL,
  `alamat_admin` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `username_admin`, `password_admin`, `foto_admin`, `alamat_admin`) VALUES
(1, 'Ridwan Dwi Irawan', 'ridwan', 'ridwan02', 'foto.jpg', 'Jl. Bendo'),
(2, 'Aldy', 'aldo', 'alda', 'foto.png', 'Sukoharjo'),
(3, 'Mellah', 'rizka', 'erik', 'mella.jpg', 'mamuju'),
(4, 'Admin', 'admin', 'admin', 'foto.jpg', 'Jogja');

-- --------------------------------------------------------

--
-- Struktur dari tabel `alternatif`
--

CREATE TABLE `alternatif` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `Penalaran` tinyint(4) NOT NULL,
  `Verbalisasi` tinyint(4) NOT NULL,
  `Sistematika` tinyint(4) NOT NULL,
  `Logika` tinyint(4) NOT NULL,
  `Fleksibilitas` tinyint(4) NOT NULL,
  `Imajinasi` tinyint(4) NOT NULL,
  `Antisipasi` tinyint(4) NOT NULL,
  `Potensi` tinyint(4) NOT NULL,
  `Tanggungjawab` tinyint(4) NOT NULL,
  `Vitalitas` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `alternatif`
--

INSERT INTO `alternatif` (`id`, `nama`, `Penalaran`, `Verbalisasi`, `Sistematika`, `Logika`, `Fleksibilitas`, `Imajinasi`, `Antisipasi`, `Potensi`, `Tanggungjawab`, `Vitalitas`) VALUES
(111, 'Kurniawan', 3, 4, 4, 4, 5, 3, 4, 3, 4, 4),
(112, 'Farida Nur', 5, 5, 3, 4, 3, 4, 5, 5, 4, 5),
(113, 'Samijo', 4, 4, 4, 4, 3, 4, 4, 4, 5, 4),
(114, 'aldy', 5, 4, 3, 4, 3, 2, 3, 4, 5, 5),
(115, 'ridwan', 5, 4, 5, 4, 3, 4, 5, 4, 3, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `core_factor`
--

CREATE TABLE `core_factor` (
  `id` int(11) NOT NULL,
  `Penalaran` tinyint(1) DEFAULT 0,
  `Verbalisasi` tinyint(1) DEFAULT 0,
  `Sistematika` tinyint(1) DEFAULT 0,
  `Logika` tinyint(1) DEFAULT 0,
  `Fleksibilitas` tinyint(1) NOT NULL,
  `Imajinasi` tinyint(1) NOT NULL,
  `Antisipasi` tinyint(1) NOT NULL,
  `Potensi` tinyint(1) NOT NULL,
  `Tanggungjawab` tinyint(1) NOT NULL,
  `Vitalitas` tinyint(1) NOT NULL,
  `percentage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `core_factor`
--

INSERT INTO `core_factor` (`id`, `Penalaran`, `Verbalisasi`, `Sistematika`, `Logika`, `Fleksibilitas`, `Imajinasi`, `Antisipasi`, `Potensi`, `Tanggungjawab`, `Vitalitas`, `percentage`) VALUES
(79, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 60),
(80, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 60),
(81, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 60);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kriteria`
--

CREATE TABLE `kriteria` (
  `id` int(11) NOT NULL,
  `Penalaran` tinyint(4) NOT NULL,
  `Verbalisasi` tinyint(4) NOT NULL,
  `Sistematika` tinyint(4) NOT NULL,
  `Logika` tinyint(4) NOT NULL,
  `Fleksibilitas` tinyint(4) NOT NULL,
  `Imajinasi` tinyint(4) NOT NULL,
  `Antisipasi` tinyint(4) NOT NULL,
  `Potensi` tinyint(4) NOT NULL,
  `Tanggungjawab` tinyint(4) NOT NULL,
  `Vitalitas` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kriteria`
--

INSERT INTO `kriteria` (`id`, `Penalaran`, `Verbalisasi`, `Sistematika`, `Logika`, `Fleksibilitas`, `Imajinasi`, `Antisipasi`, `Potensi`, `Tanggungjawab`, `Vitalitas`) VALUES
(79, 3, 3, 4, 4, 4, 5, 3, 4, 4, 5),
(80, 3, 3, 4, 4, 4, 5, 3, 4, 4, 5),
(81, 3, 3, 4, 4, 4, 5, 3, 4, 4, 5),
(82, 3, 3, 4, 4, 4, 5, 3, 4, 4, 5),
(83, 3, 3, 4, 4, 4, 5, 3, 4, 4, 5),
(84, 3, 3, 4, 4, 4, 5, 3, 4, 4, 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `operator`
--

CREATE TABLE `operator` (
  `id_operator` int(12) NOT NULL,
  `nama_operator` varchar(30) DEFAULT NULL,
  `username_operator` varchar(12) DEFAULT NULL,
  `password_operator` varchar(20) NOT NULL,
  `alamat_operator` varchar(50) NOT NULL,
  `jk_operator` varchar(8) NOT NULL,
  `telepon_operator` varchar(13) NOT NULL,
  `ttl` varchar(30) NOT NULL,
  `foto_operator` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `operator`
--

INSERT INTO `operator` (`id_operator`, `nama_operator`, `username_operator`, `password_operator`, `alamat_operator`, `jk_operator`, `telepon_operator`, `ttl`, `foto_operator`) VALUES
(1, 'Ridwan Dwi Irawan', 'ridwan', 'ridwan02', 'Jl. Wahid Hasym', 'male', '089899999', '2019-12-14', 'av4.png'),
(4, 'Mella', 'mel', 'mell', 'hfgdehhsh', 'Perempua', '08987878', '2020-05-13', 'av6.png'),
(5, 'Aldy', 'alda', 'aldoan', 'aldyaldoalda', 'female', '08989989', '2020-05-21', 'favicon.png'),
(6, 'Admin', 'admin', 'admin', 'Jogja', 'L', '081987876645', 'Jogja', 'foto.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ranking`
--

CREATE TABLE `ranking` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nilai_akhir` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ranking`
--

INSERT INTO `ranking` (`id`, `nama`, `nilai_akhir`) VALUES
(1, 'Kurniawan', 4.45),
(2, 'Farida Nur', 4.2),
(3, 'Samijo', 4.5),
(4, 'aldy', 4.25),
(5, 'ridwan', 4.1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `alternatif`
--
ALTER TABLE `alternatif`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `core_factor`
--
ALTER TABLE `core_factor`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `operator`
--
ALTER TABLE `operator`
  ADD PRIMARY KEY (`id_operator`);

--
-- Indeks untuk tabel `ranking`
--
ALTER TABLE `ranking`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `alternatif`
--
ALTER TABLE `alternatif`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT untuk tabel `core_factor`
--
ALTER TABLE `core_factor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT untuk tabel `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT untuk tabel `operator`
--
ALTER TABLE `operator`
  MODIFY `id_operator` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
