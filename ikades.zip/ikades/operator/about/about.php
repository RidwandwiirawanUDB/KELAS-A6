
<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">


            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">About Us </h4>
                        <ol class="breadcrumb p-0 m-0">
                            <li>
                                <a href="#">iKaDes</a>
                            </li>
                            <li class="active">
                                About Us
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->

            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="p-20">
                        <div class="text-justify">
                            <p>
                            Aplikasi ini dibuat dengan metode GAP dimana Perhitungan akan sesuai dengan metode ini apabila alternatif yang terpilih memenuhi kriteria 
                            yang telah ditentukan. Dengan Menggunakan sistem pendukung keputusan seleksi pemilihan calon kepala desa berbasis web yang memakai metode 
                            GAP atau Profile Matching ini membantu perangkat desa dan warga masyarakat untuk mengetahui perangkingan calon kepala desa dari hasil bobot 
                            kriteria CF dan SF yang telah di tentukan,sehingga memberi informasi tambahan saat akan menetukan sebuah pilihan.
                            </p>
                        </div>

                        <div class="m-t-50 p-t-10">
                            <h4 class="text-uppercase">Behind People</h4>
                            <div class="border m-b-30"></div>

                            <div class="row about-team text-center">

                                <!-- team-member -->
                                <div class="col-sm-4">
                                    <div class="about-team-member">
                                        <img src="upload/people/ridwan.png" alt="team-member" class="img-responsive img-circle">
                                        <h4 class="text-primary">Ridwan Dwi Irawan</h4>
                                        <h5>Programmer</h5>
                                        <p>17.12.0145</p>
                                    </div>
                                </div>

                                <!-- team-member -->
                                <div class="col-sm-4">
                                    <div class="about-team-member">
                                        <img src="upload/people/mella.png" alt="team-member" class="img-responsive img-circle">
                                        <h4 class="text-primary">Rizka Mella Ayu Putri</h4>
                                        <h5>Data Analyst</h5>
                                        <p>17.12.0153</p>
                                    </div>
                                </div>

                                <!-- team-member -->
                                <div class="col-sm-4">
                                    <div class="about-team-member">
                                        <img src="upload/people/aldy.png" alt="team-member" class="img-responsive img-circle">
                                        <h4 class="text-primary">Febrian Fitrialdy</h4>
                                        <h5>UI/UX Designer</h5>
                                        <p>17.12.0193</p>
                                    </div>
                                </div>

                            </div>
                            <!-- end row -->
                            </div><div>
                        <div class="m-t-50 p-t-10">
                            <h4 class="text-uppercase">Layanan Kami</h4>
                            <div class="border m-b-30"></div>

                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="about-features-box text-center">
                                        <div class="feature-icon">
                                            <i class="ion-coffee"></i>
                                        </div>
                                        <h4>Membantu Meminimalisir Pilihan</h4>

                                        <p class="text-muted">Alternatif dapat dipersempit sehingga dapat memudahkan pengguna dalam memilih.</p>
                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="about-features-box text-center">
                                        <div class="feature-icon">
                                            <i class="ion-images"></i>
                                        </div>
                                        <h4>Dukungan Berbagai Fitur</h4>

                                        <p class="text-muted">PHP, JSON, JAVASCRIPT dan CSS telah dipadukan dalam aplikasi ini.</p>
                                    </div>
                                </div>

                                <div class="col-sm-4">
                                    <div class="about-features-box text-center">
                                        <div class="feature-icon">
                                            <i class="ion-settings"></i>
                                        </div>
                                        <h4>Desain Minimalis</h4>

                                        <p class="text-muted">Pemilihan Warna dan Layout yang simple membuat pengguna fokus dalam melakukan seleksi.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->
                        </div>
                        <!-- end services -->

                        </div>
                        <!-- end services -->


                    </div> <!-- end p-20 -->
                </div> <!-- end col -->
            </div>
            <!-- end row -->


        </div> <!-- container -->

    </div> <!-- content -->

</div>