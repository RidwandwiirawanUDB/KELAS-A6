<h5 align="center">Tabel Profile  Seleksi Kepala Desa Sukoharjo</h5>
<div class="text-left">
<table class="table m-0 table-colored table-primary">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Calon Kepala Desa</th>
        <th>Penalaran Umum</th>
        <th>Verbalisasi Ide</th>
        <th>Sistematika Berpikir</th>
        <th>Logika Praktis</th>
        <th>Fleksibilitas Berpikir</th>
        <th>Imajinasi Kreatif</th>
        <th>Antisipasi</th>
        <th>Potensi Kecerdasan</th>
        <th>Tanggungjawab</th>
        <th>Vitalitas Perencanaan</th>
      </tr>
    </thead>
    <tbody>
    <?php while($alternatif=mysqli_fetch_array($query)){ ?>
      <?php $datas[] = $alternatif; ?>
      <tr>
        <td><?=$i?></td>
        <td><?=$alternatif['nama']?></td>
        <td><?=$alternatif['penalaran']?></td>
        <td><?=$alternatif['verbalisasi']?></td>
        <td><?=$alternatif['sistematika']?></td>
        <td><?=$alternatif['logika']?></td>
        <td><?=$alternatif['fleksibilitas']?></td>
        <td><?=$alternatif['imajinasi']?></td>
        <td><?=$alternatif['antisipasi']?></td>
        <td><?=$alternatif['potensi']?></td>
        <td><?=$alternatif['tanggungjawab']?></td>
        <td><?=$alternatif['vitalitas']?></td>
      </tr>
      <?php $i++ ?>
    <?php } $i=1;?>

    <tr class="red-text" style="font-weight:bold;">
      <td> </td>
      <td class="text-danger"> = Kriteria yang diinginkan =</td>
      <?php $k=mysqli_fetch_array($query_kriteria); ?>
      <td class="text-danger"><?=$k1=$k['penalaran']?></td>
      <td class="text-danger"><?=$k2=$k['verbalisasi']?></td>
      <td class="text-danger"><?=$k3=$k['sistematika']?></td>
      <td class="text-danger"><?=$k4=$k['logika']?></td>
      <td class="text-danger"><?=$k5=$k['fleksibilitas']?></td>
      <td class="text-danger"><?=$k6=$k['imajinasi']?></td>
      <td class="text-danger"><?=$k7=$k['antisipasi']?></td>
      <td class="text-danger"><?=$k8=$k['potensi']?></td>
      <td class="text-danger"><?=$k9=$k['tanggungjawab']?></td>
      <td class="text-danger"><?=$k10=$k['vitalitas']?></td>
    </tr>

    </tbody>
</table>
