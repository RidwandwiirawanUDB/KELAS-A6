<!-- Author: Khihady Sucahyo -->

<!-- Tabel Bobot -->
<hr><br>
<h5 align="center">Tabel Nilai Bobot Hasil  Seleksi Kepala Desa Sukoharjo</h5>
<div class="text-left">
<table class="table m-0 table-colored table-primary">

    <thead>
      <?php $cf=mysqli_fetch_array($query_cf); ?>
      <tr>
        <th>No</th>
        <th>Nama Calon Kepala Desa</th>
        <th>Penalaran Umum</th>  
        <th>Verbalisasi Ide</th>
        <th>Sistematika Berpikir</th>
        <th>Logika Praktis</th>
        <th>Fleksibilitas Berpikir</th>
        <th>Imajinasi Kreatif</th>
        <th>Antisipasi</th>
        <th>Potensi Kecerdasan</th>
        <th>Tanggungjawab</th>
        <th>Vitalitas Perencanaan</th>
        <th>NCF <?='('.$cf['percentage'].'%)'?></th>
        <th>NSF <?='('.(100-$cf['percentage']).'%)'?></th>
        <th>Nilai Total</th>
      </tr>
    </thead>

    <?php include 'assets/php/classCoreFactor.php'; ?>

    <tbody>
    <?php foreach($datas as $data){ ?>
      <tr>
        <td><?=$i?></td>
        <td><?=$data['nama']?></td>
        <td>
          <?=$b_penalaran[$i]=hitungBobot($data['penalaran']-$k1) ?>
        </td>
        <td>
          <?=$b_verbalisasi[$i]=hitungBobot($data['verbalisasi']-$k2) ?>
        </td>
        <td>
          <?=$b_sistematika[$i]=hitungBobot($data['sistematika']-$k3) ?>
        </td>
        <td>
          <?=$b_logika[$i]=hitungBobot($data['logika']-$k4) ?>
        </td>
        <td>
          <?=$b_fleksibilitas[$i]=hitungBobot($data['fleksibilitas']-$k5) ?>
        </td>
        <td>
          <?=$b_imajinasi[$i]=hitungBobot($data['imajinasi']-$k6) ?>
        </td>
        <td>
          <?=$b_antisipasi[$i]=hitungBobot($data['antisipasi']-$k7) ?>
        </td>
        <td>
          <?=$b_potensi[$i]=hitungBobot($data['potensi']-$k8) ?>
        </td>
        <td>
          <?=$b_tanggungjawab[$i]=hitungBobot($data['tanggungjawab']-$k9) ?>
        </td>
        <td>
          <?=$b_vitalitas[$i]=hitungBobot($data['vitalitas']-$k10) ?>
        </td>

        <!-- Menghitung NCF -->
        <?php
        $cf1[$i] = ($cfpenalaran==1)   ? $b_penalaran[$i]  :0;
        $cf2[$i] = ($cfverbalisasi==1) ? $b_verbalisasi[$i]:0;
        $cf3[$i] = ($cfsistematika==1)  ? $b_sistematika[$i] :0;
        $cf4[$i] = ($cflogika==1)    ? $b_logika[$i]   :0;
        $cf5[$i] = ($cffleksibilitas==1)   ? $b_fleksibilitas[$i]  :0;
        $cf6[$i] = ($cfimajinasi==1) ? $b_imajinasi[$i]:0;
        $cf7[$i] = ($cfantisipasi==1)  ? $b_antisipasi[$i] :0;
        $cf8[$i] = ($cfpotensi==1)    ? $b_potensi[$i]   :0;
        $cf9[$i] = ($cftanggungjawab==1)   ? $b_tanggungjawab[$i]  :0;
        $cf10[$i] = ($cfvitalitas==1) ? $b_vitalitas[$i]:0;
        $ncf[$i]=($cf1[$i]+$cf2[$i]+$cf3[$i]+$cf4[$i]+$cf5[$i]+$cf6[$i]+$cf7[$i]+$cf8[$i]+$cf9[$i]+$cf10[$i])/$banyak_cf;
        ?>

        <!-- Menghitung NSF -->
        <?php
        $sf1[$i] = ($cfpenalaran==0)   ? $b_penalaran[$i]  :0;
        $sf2[$i] = ($cfverbalisasi==0) ? $b_verbalisasi[$i]:0;
        $sf3[$i] = ($cfsistematika==0)  ? $b_sistematika[$i] :0;
        $sf4[$i] = ($cflogika==0)    ? $b_logika[$i]   :0;
        $sf5[$i] = ($cffleksibilitas==0)   ? $b_fleksibilitas[$i]  :0;
        $sf6[$i] = ($cfimajinasi==0) ? $b_imajinasi[$i]:0;
        $sf7[$i] = ($cfantisipasi==0)  ? $b_antisipasi[$i] :0;
        $sf8[$i] = ($cfpotensi==0)    ? $b_potensi[$i]   :0;
        $sf9[$i] = ($cftanggungjawab==0)   ? $b_tanggungjawab[$i]  :0;
        $sf10[$i] = ($cfvitalitas==0) ? $b_vitalitas[$i]:0;
        $nsf[$i] = ($sf1[$i]+$sf2[$i]+$sf3[$i]+$sf4[$i])/$+$sf5[$i]+$sf6[$i]+$sf7[$i]+$sf8[$i]+$sf9[$i]+$sf10[$i]banyak_sf;
        ?>

        <!-- Menghitung Nilai Total -->
        <?php
        $cfPercentage = $cf['percentage'];
        $sfPercentage = 100-$cfPercentage;
        $na[$i] = ($cfPercentage/100*$ncf[$i]) + ($sfPercentage/100*$nsf[$i]);
        ?>

        <td><?=$ncf[$i]?></td>
        <td><?=$nsf[$i]?></td>
        <td><?=$na[$i]?></td>
      </tr>
      <?php $i++ ?>
    <?php } $i=1;?>
  </tbody>
</table>
<!-- End Tabel Bobot -->
