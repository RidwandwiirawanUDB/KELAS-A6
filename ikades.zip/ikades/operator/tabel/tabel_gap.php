<!-- Author: Khihady Sucahyo -->

<!-- Tabel GAP -->
<hr><br>
<h5 align="center">= Tabel GAP =</h5>
<table class="striped centered">
  <thead>
    <tr>
        <th>No</th>
        <th>Nama Calon Kepala Desa</th>
        <th>Penalaran Umum</th>
        <th>Verbalisasi Ide</th>
        <th>Sistematika Berpikir</th>
        <th>Logika Praktis</th>
        <th>Fleksibilitas Berpikir</th>
        <th>Imajinasi Kreatif</th>
        <th>Antisipasi</th>
        <th>Potensi Kecerdasan</th>
        <th>Tanggungjawab</th>
        <th>Vitalitas Perencanaan</th>
    </tr>
  </thead>
    <tbody>
      <?php foreach($datas as $data){ ?>
        <tr>
          <?php
           ?>
          <td><?=$i?></td>
          <td><?=$data['nama']?></td>
          <td><?=$data['penalaran']-$k1?></td>
          <td><?=$data['verbalisasi']-$k2?></td>
          <td><?=$data['sistematika']-$k3?></td>
          <td><?=$data['logika']-$k4?></td>
          <td><?=$data['fleksibilitas']-$k1?></td>
          <td><?=$data['imajinasi']-$k2?></td>
          <td><?=$data['antisipasi']-$k3?></td>
          <td><?=$data['potensi']-$k4?></td>
          <td><?=$data['tanggungjawab']-$k1?></td>
          <td><?=$data['vitalitas']-$k2?></td>
        </tr>
        <?php $i++ ?>
        <?php } $i=1;?>
  </tbody>
</table>
<!-- End Tabel GAP -->
