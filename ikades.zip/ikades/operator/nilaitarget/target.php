<div class="content-page">
<!-- Start content -->
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                    <h4 class="page-title">Nilai Target</h4>
                    <ol class="breadcrumb p-0 m-0">
                        <li>
                            <a href="#">iKaDes</a>
                        </li>
                        <li class="active">
                            Nilai Target
                        </li> 
                    </ol>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div> 
        <!-- end row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card-box table-responsive">
                    <table id="datatable-responsive card-box" class="table table-striped table-bordered dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kriteria</th>
                            <th>Bobot</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                            include "lib/koneksi.php";
                            $no = 1;
                            $kueriR = mysqli_query($con,"SELECT * FROM kriteria order by id DESC limit 1");
                            while($kat=mysqli_fetch_array($kueriR)){
                        ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Penalaran</td>
                          <td><?php echo $kat['Penalaran']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Verbalisasi</td>
                          <td><?php echo $kat['Verbalisasi']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Sistematika</td>  
                          <td><?php echo $kat['Sistematika']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Logika</td>
                          <td><?php echo $kat['Logika']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Fleksibilitas</td>
                          <td><?php echo $kat['Fleksibilitas']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Imajinasi</td>
                          <td><?php echo $kat['Imajinasi']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Antisipasi</td>
                          <td><?php echo $kat['Antisipasi']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Potensi</td>
                          <td><?php echo $kat['Potensi']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Tanggung Jawab</td>
                          <td><?php echo $kat['Tanggungjawab']; ?></td>
                        </tr>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td>Vitalitas</td>
                          <td><?php echo $kat['Vitalitas']; ?></td>
                        </tr>
                        <?php }  ?>
                      </tbody>
                    </table>
                    <!-- <table id="datatable-responsive card-box" class="table table-striped table-bordered dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Penalaran Umum</th>
                            <th>Verbalisasi Ide</th>
                            <th>Sistematika Berpikir</th>
                            <th>Logika Praktis</th>
                            <th>Fleksibilitas Berpikir</th>
                            <th>Imajinasi Kreatif</th>
                            <th>Antisipasi</th>
                            <th>Potensi Kecerdasan</th>
                            <th>Tanggungjawab</th>
                            <th>Vitalitas Perencanaan</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                            include "lib/koneksi.php";
                            $kueriR = mysqli_query($con,"SELECT * FROM kriteria order by id DESC limit 1");
                            while($kat=mysqli_fetch_array($kueriR)){
                        ?>
                        <tr>
                          <td><?php echo $kat['Penalaran']; ?></td>
                          <td><?php echo $kat['Verbalisasi']; ?></td>
                          <td><?php echo $kat['Sistematika']; ?></td>
                          <td><?php echo $kat['Logika']; ?></td>
                          <td><?php echo $kat['Fleksibilitas']; ?></td>
                          <td><?php echo $kat['Imajinasi']; ?></td>
                          <td><?php echo $kat['Antisipasi']; ?></td>
                          <td><?php echo $kat['Potensi']; ?></td>
                          <td><?php echo $kat['Tanggungjawab']; ?></td>
                          <td><?php echo $kat['Vitalitas']; ?></td>
                        </tr>
                        <?php }  ?>
                      </tbody>
                    </table> -->
                    <hr />
                </div>
                </div>
            </div>
        </div>
