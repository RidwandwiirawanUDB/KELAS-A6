<div class="content-page">
<!-- Start content -->
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                    <h4 class="page-title">Pembobotan GAP</h4>
                    <ol class="breadcrumb p-0 m-0">
                        <li>
                            <a href="#">iKaDes</a>
                        </li>
                        <li class="active">
                            Pembobotan GAP
                        </li> 
                    </ol>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div> 
        <!-- end row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card-box table-responsive">
                    <table class="table m-0 table-colored table-inverse">
                        <thead>
                            <tr>
                                <th colspan="3"><center>Tabel Pembobotan GAP (Profile Matching)</center></th>
                            </tr>
                            <tr>
                                <th>#</th>
                                <th>Nilai Selisih</th>
                                <th>Nilai Bobot GAP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">1</th>
                                <td>0</td>
                                <td>5</td>
                            </tr>
                            <tr>
                                <th scope="row">2</th>
                                <td>1</td>
                                <td>4,5</td>
                            </tr>
                            <tr>
                                <th scope="row">3</th>
                                <td>-1</td>
                                <td>4</td>
                            </tr>
                            <tr>
                                <th scope="row">4</th>
                                <td>2</td>
                                <td>3,5</td>
                            </tr>
                            <tr>
                                <th scope="row">5</th>
                                <td>-2</td>
                                <td>3</td>
                            </tr>
                            <tr>
                                <th scope="row">6</th>
                                <td>3</td>
                                <td>2,5</td>
                            </tr>
                            <tr>
                                <th scope="row">7</th>
                                <td>-3</td>
                                <td>2</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                    <hr />
                </div>
                </div>
            </div>
        </div>
