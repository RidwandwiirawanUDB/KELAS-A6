<?php

include 'lib/koneksi.php';
if (!isset($_POST['proses'])) {
  header('location: index.php');
}
$jml_alternatif   = $_POST['jml_alternatif'];
$cf_penalaran   = 1;
$cf_verbalisasi = 1;
$cf_sistematika  = 0;
$cf_logika    = 0;
$cf_fleksibilitas   = 0; 
$cf_imajinasi = 1;
$cf_antisipasi  = 1;
$cf_potensi    = 0;
$cf_tanggungjawab    = 1;
$cf_vitalitas    = 1;
$cf_percentage = 60;

                   
//kriteria diinginkan
$kt_penalaran   = $_POST['kt_penalaran'];
$kt_verbalisasi = $_POST['kt_verbalisasi'];
$kt_sistematika  = $_POST['kt_sistematika'];
$kt_logika    = $_POST['kt_logika'];
$kt_fleksibilitas   = $_POST['kt_fleksibilitas'];
$kt_imajinasi = $_POST['kt_imajinasi'];
$kt_antisipasi  = $_POST['kt_antisipasi'];
$kt_potensi    = $_POST['kt_potensi'];
$kt_tanggungjawab    = $_POST['kt_tanggungjawab'];
$kt_vitalitas    = $_POST['kt_vitalitas'];

for ($i=1; $i<=$jml_alternatif; $i++) {
  mysqli_query($koneksi, "insert into alternatif(id,nama,penalaran,verbalisasi,sistematika,logika,fleksibilitas,imajinasi,antisipasi,potensi,tanggungjawab,vitalitas) values (null,'".
    $_POST['nama'.$i]."',".
    $_POST['penalaran'.$i].",".
    $_POST['verbalisasi'.$i].",".
    $_POST['sistematika'.$i].",".
    $_POST['logika'.$i].",".
    $_POST['fleksibilitas'.$i].",".
    $_POST['imajinasi'.$i].",".
    $_POST['antisipasi'.$i].",".
    $_POST['potensi'.$i].",".
    $_POST['tanggungjawab'.$i].",".
    $_POST['vitalitas'.$i].")"
  );
}

$query  = "insert into kriteria values (null,".$kt_penalaran.",".$kt_verbalisasi.",".$kt_sistematika.",".$kt_logika.",".$kt_fleksibilitas.",".$kt_imajinasi.",".$kt_antisipasi.",".$kt_potensi.",".$kt_tanggungjawab.",".$kt_vitalitas.");";
$query .= "insert into core_factor values (null,".$cf_penalaran.",".$cf_verbalisasi.",".$cf_sistematika.",".$cf_logika.",".$cf_fleksibilitas.",".$cf_imajinasi.",".$cf_antisipasi.",".$cf_potensi.",".$cf_tanggungjawab.",".$cf_vitalitas.",".$cf_percentage.");";
mysqli_multi_query($koneksi, $query);
echo "<script>window.location='../../dashboard.php?module=report';</script>";

?>
