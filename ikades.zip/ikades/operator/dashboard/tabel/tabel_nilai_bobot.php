<!-- Tabel Bobot -->
<hr><br>
<h4 align="center">Tabel Nilai Bobot Hasil  Seleksi Kepala Desa Sukoharjo</h4>
<div class="text-left">
<table id="datatable-keytable" class="table-bordered table m-0 table-colored table-teal">

    <thead>
      <?php $cf=mysqli_fetch_array($query_cf); ?>
      <tr>
        <th>No</th>
        <th>Nama Calon Kepala Desa</th>
        <th>Penalaran Umum</th>
        <th>Verbalisasi Ide</th>
        <th style="background-color:#FFD708;color: #000000;">Sistematika Berpikir</th>
        <th style="background-color:#FFD708;color: #000000;">Logika Praktis</th>
        <th style="background-color:#FFD708;color: #000000;">Fleksibilitas Berpikir</th>
        <th>Imajinasi Kreatif</th>
        <th>Antisipasi</th>
        <th style="background-color:#FFD708;color: #000000;">Potensi Kecerdasan</th>
        <th>Tanggungjawab</th>
        <th>Vitalitas Perencanaan</th>
        <th style="background-color:#DD5D00;">NCF <?='('.$cf['percentage'].'%)'?></th>
        <th style="background-color:#DD5D00;">NSF <?='('.(100-$cf['percentage']).'%)'?></th>
        <th style="background-color:#B11E31;">Nilai Total</th>
      </tr>
    </thead>

    <?php include 'operator/dashboard/assets/php/classCoreFactor.php'; ?>

    <tbody>
    <?php foreach($datas as $data){ ?>
      <tr>
        <td><?=$i?></td>
        <td><?=$data['nama']?></td>
        <td>
          <?=$b_penalaran[$i]=hitungBobot($data['Penalaran']-$k1) ?>
        </td>
        <td>
          <?=$b_verbalisasi[$i]=hitungBobot($data['Verbalisasi']-$k2) ?>
        </td>
        <td style="background-color:#FEE698;color: #000000;">
          <?=$b_sistematika[$i]=hitungBobot($data['Sistematika']-$k3) ?>
        </td>
        <td style="background-color:#FEE698;color: #000000;">
          <?=$b_logika[$i]=hitungBobot($data['Logika']-$k4) ?>
        </td>
        <td style="background-color:#FEE698;color: #000000;">
          <?=$b_fleksibilitas[$i]=hitungBobot($data['Fleksibilitas']-$k5) ?>
        </td>
        <td>
          <?=$b_imajinasi[$i]=hitungBobot($data['Imajinasi']-$k6) ?>
        </td>
        <td>
          <?=$b_antisipasi[$i]=hitungBobot($data['Antisipasi']-$k7) ?>
        </td>
        <td style="background-color:#FEE698;color: #000000;">
          <?=$b_potensi[$i]=hitungBobot($data['Potensi']-$k8) ?>
        </td>
        <td>
          <?=$b_tanggungjawab[$i]=hitungBobot($data['Tanggungjawab']-$k9) ?>
        </td>
        <td>
          <?=$b_vitalitas[$i]=hitungBobot($data['Vitalitas']-$k10) ?>
        </td>

        <!-- Menghitung NCF -->
        <?php
        $cf1[$i] = ($cfPenalaran==1)   ? $b_penalaran[$i]  :0;
        $cf2[$i] = ($cfVerbalisasi==1) ? $b_verbalisasi[$i]:0;
        $cf3[$i] = ($cfSistematika==1)  ? $b_sistematika[$i] :0;
        $cf4[$i] = ($cfLogika==1)    ? $b_logika[$i]   :0;
        $cf5[$i] = ($cfFleksibilitas==1)   ? $b_fleksibilitas[$i]  :0;
        $cf6[$i] = ($cfImajinasi==1) ? $b_imajinasi[$i]:0;
        $cf7[$i] = ($cfAntisipasi==1)  ? $b_antisipasi[$i] :0;
        $cf8[$i] = ($cfPotensi==1)    ? $b_potensi[$i]   :0;
        $cf9[$i] = ($cfTanggungjawab==1)   ? $b_tanggungjawab[$i]  :0;
        $cf10[$i] = ($cfVitalitas==1) ? $b_vitalitas[$i]:0;
        $ncf[$i]=($cf1[$i]+$cf2[$i]+$cf3[$i]+$cf4[$i]+$cf5[$i]+$cf6[$i]+$cf7[$i]+$cf8[$i]+$cf9[$i]+$cf10[$i])/$banyak_cf;
        ?>

        <!-- Menghitung NSF -->
        <?php
        $sf1[$i] = ($cfPenalaran==0)   ? $b_penalaran[$i]  :0;
        $sf2[$i] = ($cfVerbalisasi==0) ? $b_verbalisasi[$i]:0;
        $sf3[$i] = ($cfSistematika==0)  ? $b_sistematika[$i] :0;
        $sf4[$i] = ($cfLogika==0)    ? $b_logika[$i]   :0;
        $sf5[$i] = ($cfFleksibilitas==0)   ? $b_fleksibilitas[$i]  :0;
        $sf6[$i] = ($cfImajinasi==0) ? $b_imajinasi[$i]:0;
        $sf7[$i] = ($cfAntisipasi==0)  ? $b_antisipasi[$i] :0;
        $sf8[$i] = ($cfPotensi==0)    ? $b_potensi[$i]   :0;
        $sf9[$i] = ($cfTanggungjawab==0)   ? $b_tanggungjawab[$i]  :0;
        $sf10[$i] = ($cfVitalitas==0) ? $b_vitalitas[$i]:0;
        $nsf[$i] = ($sf1[$i]+$sf2[$i]+$sf3[$i]+$sf4[$i]+$sf5[$i]+$sf6[$i]+$sf7[$i]+$sf8[$i]+$sf9[$i]+$sf10[$i])/$banyak_sf;
        ?>

        <!-- Menghitung Nilai Total -->
        <?php
        $cfPercentage = $cf['percentage'];
        $sfPercentage = 100-$cfPercentage;
        $na[$i] = ($cfPercentage/100*$ncf[$i]) + ($sfPercentage/100*$nsf[$i]);
        ?>

        <td style="background-color:#F7A538;color: #000000;"><?=$ncf[$i]?></td>
        <td style="background-color:#F7A538;color: #000000;"><?=$nsf[$i]?></td>
        <td style="background-color:#ED6767;color: #000000;"><?=$na[$i]?></td>
      </tr>
      <?php $i++ ?>
    <?php } $i=1;?>
  </tbody>
</table>
<!-- End Tabel Bobot -->
