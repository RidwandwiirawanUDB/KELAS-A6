<!-- Tabel GAP -->
<hr><br>
<h4 align="center">Tabel GAP  Seleksi Kepala Desa Sukoharjo</h4>
<div class="text-left">
<table id="datatable-keytable" class="table-bordered table m-0 table-colored table-teal">
  <thead>
    <tr>
        <th>No</th>
        <th>Nama Calon Kepala Desa</th>
        <th>Penalaran Umum</th>
        <th>Verbalisasi Ide</th>
        <th style="background-color:#FFD708;color: #000000;">Sistematika Berpikir</th>
        <th style="background-color:#FFD708;color: #000000;">Logika Praktis</th>
        <th style="background-color:#FFD708;color: #000000;">Fleksibilitas Berpikir</th>
        <th>Imajinasi Kreatif</th>
        <th>Antisipasi</th>
        <th style="background-color:#FFD708;color: #000000;">Potensi Kecerdasan</th>
        <th>Tanggungjawab</th>
        <th>Vitalitas Perencanaan</th>
    </tr>
  </thead>
    <tbody>
      <?php foreach($datas as $data){ ?>
        <tr>
          <?php
           ?>
          <td><?=$i?></td>
          <td><?=$data['nama']?></td>
          <td><?=$data['Penalaran']-$k1?></td>
          <td><?=$data['Verbalisasi']-$k2?></td>
          <td style="background-color:#FEE698;color: #000000;"><?=$data['Sistematika']-$k3?></td>
          <td style="background-color:#FEE698;color: #000000;"><?=$data['Logika']-$k4?></td>
          <td style="background-color:#FEE698;color: #000000;"><?=$data['Fleksibilitas']-$k5?></td>
          <td><?=$data['Imajinasi']-$k6?></td>
          <td><?=$data['Antisipasi']-$k7?></td>
          <td style="background-color:#FEE698;color: #000000;"><?=$data['Potensi']-$k8?></td>
          <td><?=$data['Tanggungjawab']-$k9?></td>
          <td><?=$data['Vitalitas']-$k10?></td>
        </tr>
        <?php $i++ ?>
        <?php } $i=1;?>
  </tbody>
</table>
<!-- End Tabel GAP -->
