<h4 align="center">Tabel Profile  Seleksi Kepala Desa Sukoharjo</h4>
<div class="text-left">
<table id="datatable-keytable" class="table-bordered table m-0 table-colored table-teal">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama Calon Kepala Desa</th>
        <th>Penalaran Umum</th>
        <th>Verbalisasi Ide</th>
        <th style="background-color:#FFD708;color: #000000;">Sistematika Berpikir</th>
        <th style="background-color:#FFD708;color: #000000;">Logika Praktis</th>
        <th style="background-color:#FFD708;color: #000000;">Fleksibilitas Berpikir</th>
        <th>Imajinasi Kreatif</th>
        <th>Antisipasi</th>
        <th style="background-color:#FFD708;color: #000000;">Potensi Kecerdasan</th>
        <th>Tanggungjawab</th>
        <th>Vitalitas Perencanaan</th>
      </tr>
    </thead>
    <tbody> 
    <?php while($alternatif=mysqli_fetch_array($query)){ ?>
      <?php $datas[] = $alternatif; ?>
      <tr>
        <td><?=$i?></td>
        <td><?=$alternatif['nama']?></td>
        <td><?=$alternatif['Penalaran']?></td>
        <td><?=$alternatif['Verbalisasi']?></td>
        <td style="background-color:#FEE698;color: #000000;"><?=$alternatif['Sistematika']?></td>
        <td style="background-color:#FEE698;color: #000000;"><?=$alternatif['Logika']?></td>
        <td style="background-color:#FEE698;color: #000000;"><?=$alternatif['Fleksibilitas']?></td>
        <td><?=$alternatif['Imajinasi']?></td>
        <td><?=$alternatif['Antisipasi']?></td>
        <td style="background-color:#FEE698;color: #000000;"><?=$alternatif['Potensi']?></td>
        <td><?=$alternatif['Tanggungjawab']?></td>
        <td><?=$alternatif['Vitalitas']?></td>
      </tr>
      <?php $i++ ?>
    <?php } $i=1;?>

    <tr class="red-text" style="font-weight:bold;">
      <td style="background-color:#AAF0D1;color: #000000;"> </td>
      <td style="background-color:#AAF0D1;color: #000000;"> Nilai Target</td>
      <?php $k=mysqli_fetch_array($query_kriteria); ?>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k1=$k['Penalaran']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k2=$k['Verbalisasi']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k3=$k['Sistematika']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k4=$k['Logika']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k5=$k['Fleksibilitas']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k6=$k['Imajinasi']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k7=$k['Antisipasi']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k8=$k['Potensi']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k9=$k['Tanggungjawab']?></td>
      <td style="background-color:#AAF0D1;color: #000000;"><?=$k10=$k['Vitalitas']?></td>
    </tr>

    </tbody>
</table>
