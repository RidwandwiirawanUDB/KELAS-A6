<div class="col s4">
    <div class="card">
      <div class="card-content">
        <!-- <div class="card-title center-align indigo-text"><strong>Biodata Peserta</strong></div> -->
        <div class="card-action">
              <input type="hidden" name="jml_alternatif" value="<?=$jml_alternatif?>">
              <table class="">
                  <thead>
                    <tr>
                      <th colspan="2">Keterangan</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>Sangat Buruk</td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Buruk</td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Sedang</td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Baik</td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>Sangat Baik</td>
                    </tr>
                  </tbody>
              </table>
        </div>
      </div>
    </div>
</div>
