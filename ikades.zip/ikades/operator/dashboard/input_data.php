<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Input Penilaian</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">iKaDes</a>
                                        </li>
                                        <li>
                                            <a href="#">Proses Data</a>
                                        </li>
                                        <li>
                                            <a href="#">Mulai Penilaian</a>
                                        </li>
                                        <li class="active">
                                            Input Penilaian
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <!-- end row -->

<?php
$jml_alternatif = $_POST['jml_alternatif'];
?>

<main>
 <div class="container">
  <div class="row">
  <main class="container valign-wrapper card-box">
  <div class="col-xs-12">
            <h4 class="header-title m-t-0">Melakukan Input Nilai Kriteria dan Nilai Target</h4>
            <p class="text-muted m-b-25 font-13">Dibawah ini adalah aturan yang dijadikan acuan dalam seleksi kepala desa.</p>
							</div>
    <div class="col-md-12">
    <div class="col-md-3">
          <div class="table-responsive">
            <!-- <div class="card-title center-align indigo-text"><strong>Biodata Peserta</strong></div> -->
                  <input type="hidden" name="jml_alternatif" value="<?=$jml_alternatif?>">
                  <table class="table m-0 table-colored table-teal">
                      <thead>
                        <tr>
                          <th colspan="2">Keterangan</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>Sangat Buruk</td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>Buruk</td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>Sedang</td>
                        </tr>
                        <tr>
                          <td>4</td>
                          <td>Baik</td>
                        </tr>
                        <tr>
                          <td>5</td>
                          <td>Sangat Baik</td>
                        </tr>
                      </tbody>
                  </table>
            </div>
</div>
<form class="form-horizontal" role="form" method="post" action="operator/dashboard/proses_data.php">
  <!-- <div class="row">
  <div class="col-xs-12">
  <h4 class="header-title m-t-0">Melakukan Input Nilai Kriteria dan Nilai Target</h4>
  <p class="text-muted m-b-25 font-13">Dibawah ini adalah form yang digunakan untuk menentukan core factor dan secondari factor serta digunakan untuk menginputkan nilai target yang diinginkan oleh Pengguna.</p>
    </div>
  <div class="col-md-12">
  <div class="col-md-3">
  <div class="text-left">
      <div class="table-responsive">
              <table class="table m-0 table-colored table-inverse">
                  <thead>
                    <tr>
                      <th colspan="2">Core Factor</th>
                    </tr>
                  </thead>
                  <tbody>
                  <form class="form-horizontal" role="form" method="post" action="operator/dashboard/proses_data.php">
                    <tr>
                      <td>
                      <div class="btn-switch btn-switch-inverse">
                        <input data-parsley-multiple="groups" data-parsley-mincheck="2" id="input-btn-switch-inverse" type="checkbox" name="cf_attitude" value="1"">
                        <label for="input-btn-switch-inverse" class="btn btn-rounded btn-inverse waves-effect waves-light">
                            <em class="glyphicon glyphicon-ok"></em>
                            <strong> Attitude</strong>
                        </label>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                      <div class="btn-switch btn-switch-inverse">
                        <input data-parsley-multiple="groups" data-parsley-mincheck="2" id="input-btn-switch-inverse penampilan" type="checkbox" name="cf_penampilan" value="1"">
                        <label for="input-btn-switch-inverse penampilan" class="btn btn-rounded btn-inverse waves-effect waves-light">
                            <em class="glyphicon glyphicon-ok"></em>
                            <strong> Penampilan</strong>
                        </label>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                      <div class="btn-switch btn-switch-inverse">
                        <input data-parsley-multiple="groups" data-parsley-mincheck="2" id="input-btn-switch-inverse keaktifan" type="checkbox" name="cf_keaktifan" value="1"">
                        <label for="input-btn-switch-inverse keaktifan" class="btn btn-rounded btn-inverse waves-effect waves-light">
                            <em class="glyphicon glyphicon-ok"></em>
                            <strong> Keaktifan</strong>
                        </label>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                      <div class="btn-switch btn-switch-inverse">
                        <input data-parsley-multiple="groups" data-parsley-mincheck="2" id="input-btn-switch-inverse ekonomi" type="checkbox" name="cf_ekonomi" value="1"">
                        <label for="input-btn-switch-inverse ekonomi" class="btn btn-rounded btn-inverse waves-effect waves-light">
                            <em class="glyphicon glyphicon-ok"></em>
                            <strong> Ekonomi</strong>
                        </label>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="cf_percentage">Percentage Core Factor dalam %</label>
                        <input required class="form-control" type="text" name="cf_percentage" id="cf_percentage">
                      </td>
                    </tr>
                  </tbody>
              </table>
        </div>
      </div>
</div> -->
<div class="col-md-5">
      <!-- <div class="card-box">
          <h4 class="header-title m-t-0">Popovers</h4>
          <p class="text-muted m-b-25 font-13">Add small overlays of content, like those on
              the iPad, to any element for housing secondary information.</p> -->
          <!-- <div class="demo-popover">
              <div class="popover right">
                  <div class="arrow"></div>
                  <h3 class="popover-title">Cara Menentukan CF dan SF</h3>
                  <div class="popover-content"><p>Pada form disamping akan digunakan untuk menentukan core factor atau secondary factor dengan menekan switch pada masing masing kriteria serta menginputkan bersar presentasi core factornya.</p></div>
                      </div>
</div></div>
          <div class="col-md-3"> -->
    <div class="card">
      <div class="card-content">
        <div class="card-action">
          <table class="table m-0 table-colored-full table-full-inverse table-hover">
              <thead>
                <tr>
                <th colspan="10" class="text-center">Nilai Target tiap tiap Kriteria</th>
                </tr>
                <tr>
                  <th class="text-center">K1</th>
                  <th class="text-center">K2</th>
                  <th class="text-center">K3</th>
                  <th class="text-center">K4</th>
                  <th class="text-center">K5</th>
                  <th class="text-center">K6</th>
                  <th class="text-center">K7</th>
                  <th class="text-center">K8</th>
                  <th class="text-center">K9</th>
                  <th class="text-center">K10</th>
                </tr>
              </thead>
              <?php                                                
                  include "lib/koneksi.php";
                  $querypenilaianA = mysqli_query ($con, "SELECT *  FROM kriteria LIMIT 1"); 
                  while($A=mysqli_fetch_array($querypenilaianA)){
              ?>  
              <tbody>
              <tr>
                <td><input type="text" class="form-control" required name="kt_penalaran" value="<?php echo $A['Penalaran'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_verbalisasi" value="<?php echo $A['Verbalisasi'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_sistematika" value="<?php echo $A['Sistematika'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_logika" value="<?php echo $A['Logika'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_fleksibilitas" value="<?php echo $A['Fleksibilitas'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_imajinasi" value="<?php echo $A['Imajinasi'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_antisipasi" value="<?php echo $A['Antisipasi'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_potensi" value="<?php echo $A['Potensi'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_tanggungjawab" value="<?php echo $A['Tanggungjawab'];?>" readonly=""></td>
                <td><input type="text" class="form-control" required name="kt_vitalitas" value="<?php echo $A['Vitalitas'];?>" readonly=""></td>
            <?php } ?>
            </tr>
            </tbody>
            </table>
        </div>
      </div>
    </div>
</div>
  <!-- <div class="col-md-1">
      <!-- <div class="card-box">
          <h4 class="header-title m-t-0">Popovers</h4>
          <p class="text-muted m-b-25 font-13">Add small overlays of content, like those on
              the iPad, to any element for housing secondary information.</p> -->
          <!-- <div class="demo-popover">
              <div class="popover right">
                  <div class="arrow"></div>
                  <h3 class="popover-title">Cara menentukan Nilai Kriteria</h3>
                  <div class="popover-content"><ol>
                        <li>
                            Menentukan atau Menambah Alternatif Kepala Desa yang akan dipilih.
                        </li>
                        <li>
                            Menentukan Kriteria apa saja (System).
                        </li>
                        <li>
                            Menentukan Nilai Target
                        </li>
                        <li>
                            Memasukkan Nilai Tiap Kriteria
                        </li>
                    </ol></div>
                      </div>
</div></div> -->
<div class="col-md-4">
<div class="table-responsive">
                    <table class="table m-0 table-colored table-teal">
                    <thead>
                      <tr>
                      <th colspan="2">Calon Kepala Desa</th>
                  </tr>
                        <tr>
                          <th>No</th>
                          <th>Nama</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                            include "lib/koneksi.php";
                            $no = 1;
                            $kueriKriteria = mysqli_query($con,"SELECT * FROM alternatif");
                            while($kat=mysqli_fetch_array($kueriKriteria)){
                        ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo $kat['nama']; ?></td>
                        </tr>
                        <?php }  ?>
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
<div class="row">
<div class="col-xs-12">
    <h4 class="header-title m-t-0">Melakukan Input Nilai Kriteria</h4>
    <p class="text-muted m-b-25 font-13">Dibawah ini adalah form untuk menginputkan nilai kriteria dari masing masing alternatif.</p>
      </div>
  <div class="col-md-12">
<div class="text-left">
      <div class="table-responsive">
                          <input type="hidden" name="jml_alternatif" value="<?=$jml_alternatif?>">
                          <table class="table m-0 table-colored table-orange">
                              <thead>
                                <tr>
                                  <th>No</th>
                                  <th>Nama Calon Kepala Desa</th>
                                  <th>Penalaran Umum</th>
                                  <th>Verbalisasi Ide</th>
                                  <th>Sistematika Berpikir</th>
                                  <th>Logika Praktis</th>
                                  <th>Fleksibilitas Berpikir</th>
                                  <th>Imajinasi Kreatif</th>
                                  <th>Antisipasi</th>
                                  <th>Potensi Kecerdasan</th>
                                  <th>Tanggungjawab</th>
                                  <th>Vitalitas Perencanaan</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php for ($i=1; $i<=$jml_alternatif; $i++) { ?>
                                  <tr>
                                    <td><?=$i?></td>
                                    <td><input class="form-control" required type="text" class="validate" name="nama<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="penalaran<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="verbalisasi<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="sistematika<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="logika<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="fleksibilitas<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="imajinasi<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="antisipasi<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="potensi<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="tanggungjawab<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="vitalitas<?=$i?>" value=""></td>
                                  </tr>
                              <?php } ?>

                              </tbody>
                          </table>
</div>
                          <div class="row">
                            <div class="col-md-12">
                              <div class="text-center">
                                <div class="form-group">
                                <!-- <button  type="submit" name="proses" class="btn btn-primary right">
                                  Proses
                                </button> -->
                                <button class="btn btn-success waves-effect waves-effect w-md waves-light btn-lg m-b-5" type="submit" name="proses">Proses Data</button>
                              </div>
                          </div>

                      </form>
                    </div>
                  </div>
                </div>

            </div>
          </div>
        </div>
                              </div>
      </main>

