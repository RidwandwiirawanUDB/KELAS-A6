
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <div class="row">
  <div class="col-xs-12">
    <div class="page-title-box">
                        <h4 class="page-title">Hasil Penilaian</h4>
                        <ol class="breadcrumb p-0 m-0">
                            <li>
                                <a href="#">iKaDes</a>
                            </li>
                            <li class="active">
                                Hasil
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
  </div>
</div>
            <!-- end row -->
<div class="row">
<main class="container valign-wrapper">
      <div class="row"> <!-- actually the issue is here - row is not expanded to cover 100% width -->
          <div class="col s12">
            <div class="text-center card-box">
<?php
include 'lib/koneksi.php';
include 'operator/dashboard/assets/php/hitungBobot.php';
include 'operator/dashboard/assets/php/query.php';
?>
  <div class="container">
    <div class="row">
      <div class="col s12"> 
    
        <?php
          while($alternatif=mysqli_fetch_array($query)){ $datas[] = $alternatif; }
          $k=mysqli_fetch_array($query_kriteria);
          $k1=$k['Penalaran'];
          $k2=$k['Verbalisasi'];
          $k3=$k['Sistematika'];
          $k4=$k['Logika'];
          $k5=$k['Fleksibilitas'];
          $k6=$k['Imajinasi'];
          $k7=$k['Antisipasi'];
          $k8=$k['Potensi'];
          $k9=$k['Tanggungjawab'];
          $k10=$k['Vitalitas'];
        ?>

        <!-- Tabel Nilai Bobot Hasil-->
        <?php include 'operator/dashboard/tabel/tabel_nilai_bobot.php' ?>
        <!-- End Tabel Bobot -->

        <!-- Tabel Nilai Bobot Hasil-->
        <?php include 'operator/dashboard/tabel/tabel_ranking.php' ?>
        <!-- End Tabel Bobot -->
        <div class="row">
        <div class="col-md-12">
            <div class="text-center">
        <hr>
        <a class="btn btn-inverse waves-effect waves-light" role="button" href="dashboard.php?module=reportdetail"><i class="mdi mdi-alert-circle"> Lihat Detail</i></a>
      </div>
    </div>
  </div>
</main>
