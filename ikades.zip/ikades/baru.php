<div class="row">
    <div class="col-sm-12">
        <div class="card-box">
            <div class="row">
                <div class="col-md-12 m-t-sm-100">
                <button type="button" class="btn btn-block btn--md btn-primary waves-effect waves-light">Mulai Penilaian</button>
                </div>
            </div>
        </div>
    </div>
</div>