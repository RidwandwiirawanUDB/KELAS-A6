<?php 
$id_operator = $_GET['id_operator'];
$queryEdit =mysqli_query($con,"SELECT * FROM operator WHERE id_operator='$id_operator'");
$hasilQuery=mysqli_fetch_array($queryEdit);
$idUser=$hasilQuery['id_operator'];
$nama_operator=$hasilQuery['nama_operator'];
$jk_operator=$hasilQuery['jk_operator'];
$username_operator=$hasilQuery['username_operator'];
$password_operator=$hasilQuery['password_operator'];
$alamat_operator=$hasilQuery['alamat_operator'];
$foto_operator=$hasilQuery['foto_operator'];
$telepon_operator = $hasilQuery['telepon_operator'];
$ttl = $hasilQuery['ttl'];
?>
<!-- page content --> 
<div class="content-page">
<!-- Start content -->
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                    <h4 class="page-title">Dashboard Penilai</h4>
                    <ol class="breadcrumb p-0 m-0">
                        <li>
                            <a href="#">iKaDes</a>
                        </li>
                        <li>
                            <a href="#">Dashboard</a>
                        </li>
                        <li class="active">
                            Manajemen Data Operator
                        </li> 
                    </ol>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div> 
        <!-- end row -->
        <div class="row">
<div class="col-md-12 col-sm-12 col-xs-12 card-box">
  <div class="x_panel">
    <div class="x_title">
      <h2>Form Edit <small>operator</small></h2>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
      <br /> 
      <form data-parsley-validate class="form-horizontal form-label-left" action="operator/alternatif/aksi_editoperator.php" method="post" enctype="multipart/form-data">
      <input type="hidden" name="id_operator" value="<?php echo $hasilQuery['id_operator']; ?>">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="nama_operator">Nama operator <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="nama_operator" name="nama_operator" required="required" class="form-control col-md-7 col-xs-12" value="<?= $nama_operator; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12">Gender</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <div id="jk_operator" class="btn-group" data-toggle="buttons">
              <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                <input type="radio" name="jk_operator" value="male"> &nbsp; Laki laki &nbsp;
              </label>
              <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                <input type="radio" name="jk_operator" value="female"> Perempuan
              </label>
            </div>
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Username <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="last-name" name="username_operator" required="required" class="form-control col-md-7 col-xs-12" value="<?= $username_operator; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Password <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="last-name" name="password_operator" required="required" class="form-control col-md-7 col-xs-12" value="<?= $password_operator; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Alamat <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="alamat_operator" name="alamat_operator" required="required" class="form-control col-md-7 col-xs-12" value="<?= $alamat_operator; ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Telepon</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input id="middle-name" class="form-control col-md-7 col-xs-12" type="text" name="telepon_operator" value="<?= $telepon_operator; ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="middle-name1" class="control-label col-md-3 col-sm-3 col-xs-12">TTL</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input id="middle-name1" class="form-control col-md-7 col-xs-12" type="date" name="ttl" value="<?= $ttl; ?>">
          </div>
        </div>
        <div class="form-group">
          <label for="foto" class="control-label col-md-3 col-sm-3 col-xs-12">Foto Profil</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
              <input type="file" class="form-control col-md-7 col-xs-12" id="foto" name="foto_operator" value="<?= $foto_operator; ?>">
          </div>
        </div>
        <div class="ln_solid"></div>
        <div class="form-group">
          <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
            <button class="btn btn-primary" type="button">Cancel</button>
            <button type="submit" class="btn btn-success">Submit</button>
          </div>
        </div>

      </form>
    </div>
  </div>
</div>
<!-- /page content -->