<div class="content-page">
<!-- Start content -->
<div class="content">
    <div class="container">


        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                    <h4 class="page-title">Form Tambah Operator </h4>
                    <ol class="breadcrumb p-0 m-0">
                        <li>
                            <a href="#">Zircos</a>
                        </li>
                        <li>
                            <a href="#">Forms </a>
                        </li>
                        <li class="active">
                            Form Validation
                        </li>
                    </ol>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- end row -->


        <div class="row">
            <div class="col-xs-12">
                <div class="card-box">

                    <div class="row">
                        <div class="col-sm-12 col-xs-12 col-md-12">

                            <div class="p-20">
                                <form action="operator/alternatif/aksi_simpanoperator.php" method="post" enctype="multipart/form-data" data-parsley-validate novalidate>
                                    <div class="form-group">
                                        <label for="userName">Nama Operator<span class="text-danger">*</span></label>
                                        <input type="text" parsley-trigger="change" required
                                                placeholder="Masukkan Nama" class="form-control" name="nama_operator" id="userName">
                                    </div>
                                    <div class="form-group">
                                        <label for="userName2">User Name<span class="text-danger">*</span></label>
                                        <input type="text" parsley-trigger="change" required
                                                placeholder="Masukkan Username" class="form-control" name="username_operator" id="userName2">
                                    </div>
                                    <div class="form-group">
                                        <label for="pass1">Password<span class="text-danger">*</span></label>
                                        <input id="pass1" type="password" placeholder=" Masukkan Password" required
                                                class="form-control" name="password_operator">
                                    </div>
                                    <div class="form-group">
                                        <label for="userName3">Alamat<span class="text-danger">*</span></label>
                                        <input type="text" parsley-trigger="change" required
                                                placeholder="Masukan alamat" class="form-control" name="alamat_operator" id="userName3">
                                    </div>
                                    <!-- <div class="form-group">
                                        <label for="emailAddress">Email address<span class="text-danger">*</span></label>
                                        <input type="email" name="email" parsley-trigger="change" required
                                                placeholder="Enter email" class="form-control" id="emailAddress">
                                    </div> -->
                                    <div class="form-group">
                                    <label for="pass2">Jenis Kelamin<span class="text-danger">*</span></label><br>
                                        <div id="gender" class="btn-group" data-toggle="buttons">
                                        <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                            <input type="radio" name="jk_operator" value="Laki Laki"> &nbsp; Laki Laki &nbsp;
                                        </label>
                                        <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
                                            <input type="radio" name="jk_operator" value="Perempuan"> Perempuan
                                        </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="userName4">No Telepon<span class="text-danger">*</span></label>
                                        <input type="text" parsley-trigger="change" required
                                                placeholder="Masukan no telepon" class="form-control" name="telepon_operator" id="userName4">
                                    </div>
                                    <div class="form-group">
                                        <label for="userName5">TTL<span class="text-danger">*</span></label>
                                        <input type="date" parsley-trigger="change" required
                                                 class="form-control" name="ttl" id="userName5">
                                    </div>
                                    <!-- <div class="form-group">
                                        <label for="passWord2">Confirm Password <span class="text-danger">*</span></label>
                                        <input data-parsley-equalto="#pass1" type="password" required
                                                placeholder="Password" class="form-control" id="passWord2">
                                    </div> -->

                                    
                                    <div class="form-group">
                                    <label for="foto">Foto Profil<span class="text-danger">*</span></label><br>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="file" class="form-control-file" id="foto" name="foto_operator">
                                        </div>
                                    </div>

                                    <div class="form-group"> 
                                    <div class="form-group text-right m-b-0">
                                        <button class="btn btn-primary waves-effect waves-light" type="submit">
                                            Submit
                                        </button>
                                        <button type="reset" class="btn btn-default waves-effect m-l-5">
                                            Cancel
                                        </button>
                                    </div>

                                </form>
                            </div>

                        </div>

    </div> <!-- container -->

</div> <!-- content -->
</div>


<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->