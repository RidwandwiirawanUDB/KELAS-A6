<div class="content-page">
<!-- Start content -->
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                    <h4 class="page-title">Manajemen Operator</h4>
                    <ol class="breadcrumb p-0 m-0">
                        <li>
                            <a href="#">iKaDes</a>
                        </li>
                        <li class="active">
                            Data Operator
                        </li> 
                    </ol>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div> 
        <!-- end row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title"><b>Tabel Operator</b></h4>
                    <hr />
                    <table id="datatable-responsive card-box" class="table table-striped table-bordered dt-responsive nowrap">
                    <thead>
                        <tr>
                          <th>No</th>
                          <th>Nama Operator</th>
                          <th>Username</th>
                          <th>Password</th>
                          <th>Alamat</th>
                          <th>Jenis Kelamin</th>
                          <th>No Telepon</th>
                          <th>TTL</th>
                          <th>Foto</th>
                          <th>Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                            include "../lib/koneksi.php";
                            $no = 1;
                            $kueriR = mysqli_query($con,"SELECT * FROM operator");
                            while($kat=mysqli_fetch_array($kueriR)){
                        ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo $kat['nama_operator']; ?></td>
                          <td><?php echo $kat['username_operator']; ?></td>
                          <td><?php echo $kat['password_operator']; ?></td>
                          <td><?php echo $kat['alamat_operator']; ?></td>
                          <td><?php echo $kat['jk_operator']; ?></td>
                          <td><?php echo $kat['telepon_operator']; ?></td>
                          <td><?php echo $kat['ttl']; ?></td>
                          <td><img src="../upload/<?php echo $kat['foto_operator'];?>" height="30" width="30" ></td>
                          <td><div class="btn-group">
                                <a href="dashboard.php?module=edit_operator&id_operator=
                                <?php echo $kat['id_operator']; ?>" class="btn btn-info waves-effect waves-light"><i class="fa fa-edit"></i> Edit </button></a>
                                <a href="operator/alternatif/aksi_hapusoperator.php?id_operator=
                                <?php echo $kat['id_operator']; ?>" onClick="return confirm('Anda yakin ingin menghapus data ini?')" class="btn btn-danger waves-effect waves-light"><i class="fa fa-trash-o"></i> Hapus </button></a>
                            </div></td>
                        </tr>
                        <?php }  ?>
                      </tbody>
                    </table>
                    <hr />
                    <div class="form-group">
                    <a href="dashboard.php?module=tambah_operator"><button type="submit" class="btn btn-success">
                    Tambah Operator</button></a>
                    <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
                </div>
                </div>
            </div>
        </div>
