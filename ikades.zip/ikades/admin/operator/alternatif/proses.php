<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Menu Awal </h4>
                        <ol class="breadcrumb p-0 m-0">
                            <li>
                                <a href="#">Zircos</a>
                            </li>
                            <li>
                                <a href="#"> User Interface</a>
                            </li>
                            <li class="active">
                                Start
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <!-- end row -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="card-box">
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class=" m-t-0 header-title"><b>Mulai Penilaian</b></h4>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">

                                <p class="text-muted m-b-30 font-13">Kepala desa atau sebutan lain sesuai Peraturan Menteri Dalam Negeri Republik Indonesia Nomor 84 Tahun 2015 Tentang Struktur Organisasi dan Tata Kerja Pemerintah Desa, adalah pejabat Pemerintah Desa yang mempunyai wewenang, tugas dan kewajiban untuk menyelenggarakan rumah tangga desanya dan melaksanakan tugas dari Pemerintah dan Pemerintah Daerah.</p>

                                <!-- START carousel-->
                                <div id="carousel-example-captions" data-ride="carousel" class="carousel slide">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carousel-example-captions" data-slide-to="0" class="active"></li>
                                        <li data-target="#carousel-example-captions" data-slide-to="1"></li>
                                        <li data-target="#carousel-example-captions" data-slide-to="2"></li>
                                    </ol>
                                    <div role="listbox" class="carousel-inner">
                                        <div class="item active">
                                            <img src="upload/images/4.jpg" alt="First slide image">
                                            <div class="carousel-caption">
                                                <h3 class="text-white font-600">First slide label</h3>
                                                <p>
                                                    Nulla vitae elit libero, a pharetra augue mollis interdum.
                                                </p>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <img src="upload/images/1.jpg" alt="Second slide image">
                                            <div class="carousel-caption">
                                                <h3 class="text-white font-600">Second slide label</h3>
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                                </p>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <img src="upload/images/4.jpg" alt="Third slide image">
                                            <div class="carousel-caption">
                                                <h3 class="text-white font-600">Third slide label</h3>
                                                <p>
                                                    Praesent commodo cursus magna, vel scelerisque nisl consectetur.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="#carousel-example-captions" role="button" data-slide="prev" class="left carousel-control"> <span aria-hidden="true" class="fa fa-angle-left"></span> <span class="sr-only">Previous</span> </a>
                                    <a href="#carousel-example-captions" role="button" data-slide="next" class="right carousel-control"> <span aria-hidden="true" class="fa fa-angle-right"></span> <span class="sr-only">Next</span> </a>
                                </div>
                                <!-- END carousel-->
                            </div>

                            <div class="col-md-6 m-t-sm-50">

                                <p class="text-muted m-b-30 font-13">Kepala desa atau sebutan lain sesuai Peraturan Menteri Dalam Negeri Republik Indonesia Nomor 84 Tahun 2015 Tentang Struktur Organisasi dan Tata Kerja Pemerintah Desa, adalah pejabat Pemerintah Desa yang mempunyai wewenang, tugas dan kewajiban untuk menyelenggarakan rumah tangga desanya dan melaksanakan tugas dari Pemerintah dan Pemerintah Daerah.</p>

                                <!-- START carousel-->
                                <div id="carousel-example-captions-1" data-ride="carousel" class="carousel slide">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carousel-example-captions-1" data-slide-to="0" class="active"></li>
                                        <li data-target="#carousel-example-captions-1" data-slide-to="1"></li>
                                        <li data-target="#carousel-example-captions-1" data-slide-to="2"></li>
                                    </ol>
                                    <div role="listbox" class="carousel-inner">
                                        <div class="item active">
                                            <img src="upload/images/1.jpg" alt="First slide image">
                                        </div>
                                        <div class="item">
                                            <img src="upload/images/4.jpg" alt="Second slide image">
                                        </div>
                                        <div class="item">
                                            <img src="upload/images/1.jpg" alt="Third slide image">
                                        </div>
                                    </div>

                                </div>
                                <!-- END carousel-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="card-box">
                        <div class="panel panel-color panel-teal">
                            <div class="panel-heading">
                                <h3 class="panel-title">Langkah Langkah Penting untuk dapat melakukan Penilaian pada SPK Pemilihan Kepala Desa iKaDes</h3>
                            </div>
                            <div class="panel-body">
                            <p class="text-muted m-b-20 font-13">Beberapa langkah yang harus dilakukan yaitu.</p>
                                            <ol>
                                                <li>
                                                    Menentukan atau Menambah Alternatif Kepala Desa yang akan dipilih.
                                                </li>
                                                <li>
                                                    Menentukan Kriteria apa saja (System).
                                                </li>
                                                <li>
                                                    Menentukan Faktor Utama (Primary Factor) dan Faktor Pendukung yang diperlukan (Secondary Factor).
                                                </li>
                                                <li>
                                                    Menentukan Nilai Target
                                                </li>
                                                <li>
                                                    Memasukkan Nilai Tiap Kriteria
                                                </li>
                                                <li>
                                                    Menekan Tommbol Proses
                                                </li>
                                                <li>
                                                    Data Akan diproses
                                                </li>
                                                <li>
                                                    Menampilkan Hasil
                                                    <ol>
                                                        <li>
                                                            Tabel Awal
                                                        </li>
                                                        <li>
                                                            Tabel GAP
                                                        </li>
                                                        <li>
                                                            Tabel Hasil Perangkingan
                                                        </li>
                                                        
                                                    </ol>
                                                    <li>
                                                            Detail Report Penilaian
                                                     </li>
                                                     <li>
                                                            Mencetak Hasil Penilaian
                                                     </li>
                                                </li>
                                            </ol>
                            </div>
                        </div>
                        <a href="dashboard.php?module=home">
                            <button type="button" class="btn btn-block btn--md btn-primary waves-effect waves-light">Mulai Penilaian</button></a>
                            </div>
                    </div>
                    </div>
                    </div>
        
            </div>
        </div> <!-- container -->

    </div> <!-- content -->

</div>


<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->