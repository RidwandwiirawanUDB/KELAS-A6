<?php 
	//untuk  memulai menggunakan sassion
	session_start();
	//untuk mengecek apakah session 'username' dan 'password' sudah ada atau belum, session tersebut tercipta jika operator sudah login
	//jadi jika admin blm login maka tidak dapat mengakses file ini
	if (empty($_SESSION['usernameadmin']) AND empty ($_SESSION['passadmin'])) {
		echo "<center>Untuk mengakses modul anda harus login<br>";
		echo "<a href=../../login.php><b>LOGIN</b></a></center>";
	}else{
		//untuk memasukkan file config.php dan file koneksi.php
		include "../../../lib/koneksi.php";
		//untuk menangkap variabel nama produk yang dikirim oleh form tamnbah.php
		$namaFile = $_FILES['foto_operator']['name'];
		$ukuranFile = $_FILES['foto_operator']['size'];
		$tipeFile = $_FILES['foto_operator']['type'];
		$tmpFile = $_FILES['foto_operator']['tmp_name'];

		$id_operator=$_POST['id_operator'];
		$nama_operator = $_POST['nama_operator'];
		$jk_operator = $_POST['jk_operator'];
		$username_operator = $_POST['username_operator'];
		$password_operator = $_POST['password_operator'];
		$alamat_operator = $_POST['alamat_operator'];
		$telepon_operator = $_POST['telepon_operator'];
		$ttl = $_POST['ttl'];

		$path = "../../../upload/".$namaFile;
		if ($tipeFile == "image/jpeg" || $tipeFile == "image/png") {
			if ($ukuranFile <= 100000000) {
				if (move_uploaded_file($tmpFile, $path)) {
					$queryEdit = mysqli_query($con,"UPDATE operator SET nama_operator='$nama_operator',jk_operator='$jk_operator',username_operator ='$username_operator',password_operator ='$password_operator',alamat_operator ='$alamat_operator',telepon_operator='$telepon_operator',ttl='$ttl',foto_operator ='$namaFile' WHERE id_operator='$id_operator'");
					if ($queryEdit) {
						echo "<script>alert ('Data operator berhasil di edit'); window.location = '../../dashboard.php?module=operator';</script>";
					//jika query gagal maka akan tampil alert dan halaman akan kembali ke tambah produk
					}else{
						echo "<script>alert ('Data operator gagal di edit'); window.location = '../../dashboard.php?module=edit_operator&id_operator='+'$id_operator';</script>";
					}
				}
			}
	}
}
 ?>
