<?php 
	session_start();
	if (empty($_SESSION['usernameadmin']) AND empty ($_SESSION['passadmin']))  {
		echo "<center>Untuk mengakses modul anda harus login<br>";
		echo "<a href=../../dash_admin.php><b>LOGIN</b></a></center>";
	}else{
		//untuk memasukkan file config.php dan file koneksi.php
		include "../../../lib/koneksi.php";
		//untuk menangkap variabel nama kategori yang dikirim oleh form tambah.php
		$namaFile = $_FILES['foto_operator']['name'];
		$ukuranFile = $_FILES['foto_operator']['size'];
		$tipeFile = $_FILES['foto_operator']['type'];
		$tmpFile = $_FILES['foto_operator']['tmp_name'];

		$nama_operator = $_POST['nama_operator'];
		$jk_operator = $_POST['jk_operator'];
		$username_operator = $_POST['username_operator'];
		$password_operator = $_POST['password_operator'];
		$alamat_operator = $_POST['alamat_operator'];
		$telepon_operator = $_POST['telepon_operator'];
		$ttl = $_POST['ttl'];
		//UNTUK MENYIMPAN GAMBAR
		$path = "../../../upload/".$namaFile;
		if ($tipeFile == "image/jpeg" || $tipeFile == "image/png") {
			if ($ukuranFile <= 10000000) {
				if (move_uploaded_file($tmpFile, $path)) {
					$querySimpan=mysqli_query($con, "INSERT INTO operator(nama_operator,jk_operator,username_operator, password_operator,alamat_operator,telepon_operator,ttl,foto_operator) VALUES('$nama_operator','$jk_operator','$username_operator','$password_operator','$alamat_operator','$telepon_operator','$ttl','$namaFile')");
					if ($querySimpan) {
						echo "<script>alert ('Data Operator berhasil masuk'); window.location='../../dashboard.php?module=operator';</script>";
					//jika query gagal maka akan tampil alert dan halaman akan kembali ke tambah admin
					}else{
						echo "<script>alert ('Data Operator gagal dimasukan'); window.location = '../../dashboard.php?module=form_tambahoperator.php</script>";
					}
				}
			}
		}	
	}
 ?> 