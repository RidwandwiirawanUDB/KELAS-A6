<?php 
	//untuk  memulai menggunakan session
	session_start();
	//untuk mengecek apakah session 'username' dan 'password' sudah ada atau belum, session tersebut tercipta jika admin sudah login
	//jadi jika admin blm login maka tidak dapat mengakses file ini
	if (empty($_SESSION['usernameadmin']) AND empty ($_SESSION['passadmin']))  {
		echo "<center>Untuk mengakses modul anda harus login<br>";
		echo "<a href=../index.php><b>LOGIN</b></a></center>";
	}else{
		//untuk memasukkan file config.php dan file koneksi.php
		include "../../../lib/koneksi.php";

	$id_operator=$_GET['id_operator'];
	$queryHapus=mysqli_query($con,"DELETE FROM operator WHERE id_operator='$id_operator'");
	if ($queryHapus) {
		echo "<script>alert ('Data Operator berhasil dihapus'); window.location = '../../dashboard.php?module=operator';</script>";
		//jika query gagal maka akan tampil alert dan halaman akan kembali ke tambah admin
		}else{
			echo "<script>alert ('Data Operator gagal dihapus'); window.location = '../../dashboard.php?module=operator';</script>";
		}
	}
 ?>