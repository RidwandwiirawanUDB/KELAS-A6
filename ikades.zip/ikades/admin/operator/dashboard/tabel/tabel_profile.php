<h5 align="center">Tabel Profile  Seleksi Kepala Desa Sukoharjo</h5>
<div class="text-left">
<table class="table m-0 table-colored table-primary">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Attitude</th>
        <th>Penampilan</th>
        <th>Keaktifan</th>
        <th>Ekonomi</th>
      </tr>
    </thead>
    <tbody>

    <?php while($alternatif=mysqli_fetch_array($query)){ ?>
      <?php $datas[] = $alternatif; ?>
      <tr>
        <td><?=$i?></td>
        <td><?=$alternatif['nama']?></td>
        <td><?=$alternatif['attitude']?></td>
        <td><?=$alternatif['penampilan']?></td>
        <td><?=$alternatif['keaktifan']?></td>
        <td><?=$alternatif['ekonomi']?></td>
      </tr>
      <?php $i++ ?>
    <?php } $i=1;?>

    <tr class="red-text" style="font-weight:bold;">
      <td> </td>
      <td class="text-danger"> Nilai Target yang diinginkan</td>
      <?php $k=mysqli_fetch_array($query_kriteria); ?>
      <td class="text-danger"><?=$k1=$k['attitude']?></td>
      <td class="text-danger"><?=$k2=$k['penampilan']?></td>
      <td class="text-danger"><?=$k3=$k['keaktifan']?></td>
      <td class="text-danger"><?=$k4=$k['ekonomi']?></td>
    </tr>

    </tbody>
</table>
    </div>
