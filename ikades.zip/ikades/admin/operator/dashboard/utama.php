<?php
  include 'lib/koneksi.php';
  // include 'assets/php/destroy.php';
?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Dashboard Siswa</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Cavalry</a>
                                        </li>
                                        <li>
                                            <a href="#">Dashboard</a>
                                        </li>
                                        <li class="active">
                                            Dashboard
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <!-- end row -->
<div class="row">
<main class="container valign-wrapper">
      <div class="row"> <!-- actually the issue is here - row is not expanded to cover 100% width -->
      <div class="col-sm-6">
            <div class="text-center card-box">
              
              <center><img src="upload/logoSmall.png" alt="image" class="img-responsive img-circle" width="100"></center><h2 style="color: rgb(4, 51, 83);">i-KaDes</h2>
              <p class="text-justify">
                i KaDes adalah aplikasi yang diperuntukkan untuk membantu user dalam melakukan perangkingan terhadap calon kepala desa sehingga memudahkan dalam pengambilan keputusan. 
                Kepala Desa adalah pemimpin dari pemerintahan di tingkat desa di Negara Indonesia. Masa jabatan 
                Kepala Desa adalah 6 (enam) tahun, dan dapat diperpanjang lagi untuk satu kali masa jabatan berikutnya. 
                Kepala desa tidak bertanggung jawab kepada Camat, namun hanya dikoordinasikan saja oleh Camat. Kebingungan warga untuk memilih 
                kepala Desa ibarat memilih kucing dalam karung Kita bingung memilih pemimpin yang bisa menjaga amanah masyarakat. 
                Perkembangan kemajuan tekhnologi khususnya informasi yang sangat pesat membuat perubahan di berbagai bidang, maka dari itu penulis
                berusaha membuat sebuah sistem pengambilan keputusan Untuk membatu warga masyarakat desa dalam memilih suatu pemimpin 
                desa atau kepala desa sesuai dengan syarat dan kriteria-kriteria yang ditentukan undang undang serta berdasarkan Peraturan 
                Pemerintah Republik Indonesia Nomor 72 Tahun 2005 Tentang pemilihan kepala Desa.. untuk merancang sistem pendukung keputusan 
                untuk membantu masyarakat dalam Pemilihan Pilkades dengan judul sistem pendukung keputusan penyelenggaran pemilihan 
                Kepala Desa Pekraman Beraban berbasisi Dekstop Menggunakan Metode GAP, selain itu GAP juga dapat menyeleksi alternative
                terbaik dari sejumlah alternatif yang ada karena adanya proses perankingan setelah menentukan nilai bobot untuk setiap atribut. 
                Dengan adanya aplikasi ini diharapkan dapat mengurangi permasalahan yang ada.

</p>
              
            </div>
</div>
      <div class="col-sm-6">
      <main class="container valign-wrapper">
      <div class="row"> <!-- actually the issue is here - row is not expanded to cover 100% width -->
      <div class="col-sm-12">
      <div class="text-center card-box">
              <form class="form-horizontal" role="form" method="post" action="dashboard.php?module=inputdata">
              <h2 style="color: rgb(4, 51, 83);">Menambah Jumlah Alternatif</h2><br>
              <div class="form-group">
              <input required type="text" id="state-success" class="form-control" name="jml_alternatif" placeholder="Masukkan Jumlah Alternatif" value=""><br>
                    <button  type="submit" class="btn btn-primary right">
                      Proses
                    </button>
                    </form>
                  </div>
              </div>
              </div>
              <div class="col-sm-12">
      <div class="text-center card-box">
      <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title"><b>Daftar Calon Kepala Desa</b></h4>
                    <hr />
                    <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap">
                    <thead>
                        <tr>
                          <th>No</th>
                          <th><center>Nama</center></th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                            include "lib/koneksi.php";
                            $no = 1;
                            $kueriKriteria = mysqli_query($con,"SELECT * FROM alternatif");
                            while($kat=mysqli_fetch_array($kueriKriteria)){
                        ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo $kat['nama']; ?></td>
                        </tr>
                        <?php }  ?>
                      </tbody>
                    </table>
                </div>
            </div>
        </div>
              </div>
              </div>
              </div>
              <div class="row"> 
    <div class="col-sm-12">
        <div class="card-box">
            <div class="row">
                <div class="col-lg-4">
                    <!-- <h4 class="m-t-0 header-title"><b>Tentang SMK N 1 Nglipar</b></h4> -->
                    <img src="upload/images/1.jpg" alt="image" class="img-responsive"/><br>
                    <!-- <p class="text-muted m-b-30 font-13">
                    SMK N 1 Nglipar merupakan sekolah negeri yang berbasis kejuruan yang siap untuk turut serta dalam membangun generasi negeri yang siap bekerja dan berprestrasi. 
                    SMK N 1 Nglipar juga merupakan salah satu sekolah menengah yang berdiri dikecamatan Nglipar tepatnya terletak di Pliangrejo, Nglioar, Kabupaten Gunungkidul, 
                    Daerah Istimewa Yogyakarta 55852. Sampai saat ini SMK N 1 Nglipar berhasil meluluskan lebih dari 10000 siswa yang berkompeten di bidang Teknik dan Ilmu Akuntansi. 
                    Seperti sekolah negeri pada umumnya SMK N 1 Nglipar memiliki berbagai fasilitas yang mendukung proses pembelajaran seperti 
                    Perpustakaan yang luas, Lingkungan yang bersih, Ruang kompuer, lab, bengkel praktikum dan masih banyak lainnya. 
                    </p> -->
                </div>
                <div class="col-lg-4">
                    <img src="upload/images/4.jpg" alt="image" class="img-responsive"/><br>
                </div>
                <div class="col-lg-4">
                    <img src="upload/images/2.jpg" alt="image" class="img-responsive"/><br>
                </div>

                </div>
            </div>
        </div>
    </div>
</div> <!-- end row -->
              
            
          </div>
      </div>
    </main>