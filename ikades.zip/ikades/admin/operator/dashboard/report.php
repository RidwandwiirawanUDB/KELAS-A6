
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">
            <div class="row">
  <div class="col-xs-12">
    <div class="page-title-box">
                        <h4 class="page-title">Dashboard User</h4>
                        <ol class="breadcrumb p-0 m-0">
                            <li>
                                <a href="#">Cavalry</a>
                            </li>
                            <li>
                                <a href="#">Report</a>
                            </li>
                            <li class="active">
                                Report
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
  </div>
</div>
            <!-- end row -->
<div class="row">
<main class="container valign-wrapper">
      <div class="row"> <!-- actually the issue is here - row is not expanded to cover 100% width -->
          <div class="col s12">
            <div class="text-center card-box">
<?php
include 'lib/koneksi.php';
include 'operator/dashboard/assets/php/hitungBobot.php';
include 'operator/dashboard/assets/php/query.php';
?>
  <div class="container">
    <div class="row">
      <div class="col s12">
      

        <?php
          while($alternatif=mysqli_fetch_array($query)){ $datas[] = $alternatif; }
          $k=mysqli_fetch_array($query_kriteria);
          $k1=$k['attitude'];
          $k2=$k['penampilan'];
          $k3=$k['keaktifan'];
          $k4=$k['ekonomi'];
        ?>

        <!-- Tabel Nilai Bobot Hasil-->
        <?php include 'operator/dashboard/tabel/tabel_nilai_bobot.php' ?>
        <!-- End Tabel Bobot -->

        <!-- Tabel Nilai Bobot Hasil-->
        <?php include 'operator/dashboard/tabel/tabel_ranking.php' ?>
        <!-- End Tabel Bobot -->
        <a class="btn btn-warning waves-effect waves-light" role="button" href="dashboard.php?module=reportdetail"><i class="mdi mdi-alert-circle">Lihat Detail</i></a>
      </div>
    </div>
  </div>
</main>
