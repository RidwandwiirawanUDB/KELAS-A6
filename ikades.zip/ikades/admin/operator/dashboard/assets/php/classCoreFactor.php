<?php

$cfPenalaran   = $cf['Penalaran'];
$cfVerbalisasi = $cf['Verbalisasi'];
$cfSistematika  = $cf['Sistematika'];
$cfLogika    = $cf['Logika'];
$cfFleksibilitas   = $cf['Fleksibilitas'];
$cfImajinasi = $cf['Imajinasi'];
$cfAntisipasi  = $cf['Antisipasi'];
$cfPotensi    = $cf['Potensi'];
$cfTanggungjawab   = $cf['Tanggungjawab'];
$cfVitalitas = $cf['Vitalitas'];

// die($cfAttitude.' '.$cfPenampilan.' '.$cfKeaktifan.' '.$cfEkonomi);
// $classAttitude   = ($cfAttitude  ==1) ? 'class="red"' : '';
// $classPenampilan = ($cfPenampilan==1) ? 'class="red"' : '';
// $classKeaktifan  = ($cfKeaktifan ==1) ? 'class="red"' : '';
// $classEkonomi    = ($cfEkonomi   ==1) ? 'class="red"' : '';

$banyak_cf = 6;
$banyak_sf = 4;


?>
