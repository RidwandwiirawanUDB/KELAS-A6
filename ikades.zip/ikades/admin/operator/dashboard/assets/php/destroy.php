<?php
require "../../../../../lib/koneksi.php";
$query  = "delete from alternatif;";
$query .= "delete from core_factor;";
$query .= "delete from ranking;";
mysqli_multi_query($koneksi, $query);
// echo "window.location = '../../../../dashboard.php?module=home</script>";
header('location:../../../../dashboard.php?module=main');
?>