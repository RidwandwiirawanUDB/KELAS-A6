<div class="content-page">
<!-- Start content -->
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                    <h4 class="page-title">Selesaikan Seleksi</h4>
                    <ol class="breadcrumb p-0 m-0">
                        <li>
                            <a href="#">iKaDes</a>
                        </li>
                        <li class="active">
                            Selesaikan Seleksi
                        </li> 
                    </ol>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div> 
        <!-- end row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card-box table-responsive">
                    <h4 class="m-t-0 header-title"><b>Hasil Perangkingan Terkini</b></h4>
                    <hr />
                    <table id="datatable-responsive card-box" class="table table-striped table-bordered dt-responsive nowrap">
                    <thead>
                        <tr>
                          <th>No</th>
                          <th>Nama Calon Kepala Desa</th>
                          <th>Nilai Akhir</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php 
                            include "../lib/koneksi.php";
                            $no = 1;
                            $kueriR = mysqli_query($con,"SELECT * FROM ranking order by nilai_akhir DESC");
                            while($kat=mysqli_fetch_array($kueriR)){
                        ?>
                        <tr>
                          <td><?php echo $no++; ?></td>
                          <td><?php echo $kat['nama']; ?></td>
                          <td><?php echo $kat['nilai_akhir']; ?></td>
                        </tr>
                        <?php }  ?>
                      </tbody>
                    </table>
                    <hr />
                    <div class="form-group">
                    <a href="operator/dashboard/assets/php/destroy.php"><button type="submit" class="btn btn-success" data-toggle="tooltip" data-placement="top" title="" data-original-title=" (Menghapus seluruh data seleksi)">
                    Selesaikan Seleksi</button></a>
                    <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
                </div>
                </div>
            </div>
        </div>
