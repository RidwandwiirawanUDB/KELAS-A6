<div class="content-page">
<!-- Start content -->
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                        <h4 class="page-title">Manajemen Nilai Target</h4>
                        <ol class="breadcrumb p-0 m-0">
                            <li>
                                <a href="#">iKaDes</a>
                            </li>
                            <li class="active">
                                Nilai Target
                            </li>
                        </ol>
                        <div class="clearfix"></div>
                    </div>
            </div>
        </div> 
        <!-- end row -->
        <div class="row">
<div class="col-md-12 col-sm-12 col-xs-12 card-box">
  <div class="x_panel">
    <div class="x_title">
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
      <br /> 
      <form data-parsley-validate class="form-horizontal form-label-left" action="operator/nilaitarget/aksi_edit.php" method="post">
        <?php 
            include "../lib/koneksi.php";
            $no = 1;
            $kueriR = mysqli_query($con,"SELECT * FROM kriteria order by id DESC limit 1");
            while($kat=mysqli_fetch_array($kueriR)){
        ?>
      <input type="hidden" name="id" value="<?php echo $kat['id']; ?>">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="nama_operator">Penalaran Umum<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Penalaran" name="Penalaran" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Penalaran']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Verbalisasi Ide<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Verbalisasi" name="Verbalisasi" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Verbalisasi']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Sistematika Berpikir <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Sistematika" name="Sistematika" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Sistematika']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Logika Praktis<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Logika" name="Logika" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Logika']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Fleksibilitas Berpikir<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Fleksibilitas" name="Fleksibilitas" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Fleksibilitas']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Imajinasi Kreatif<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Imajinasi" name="Imajinasi" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Imajinasi']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Antisipasi <span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Antisipasi" name="Antisipasi" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Antisipasi']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Potensi Kecerdasan<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Potensi" name="Potensi" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Potensi']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Tanggungjawab<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Tanggungjawab" name="Tanggungjawab" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Tanggungjawab']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Vitalitas Perencanaan<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Vitalitas" name="Vitalitas" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['Vitalitas']; ?>">
          </div>
        </div>
        <div class="ln_solid"></div>
        <div class="form-group">
          <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
            <button class="btn btn-primary" type="button">Cancel</button>
            <button type="submit" class="btn btn-success">Submit</button>
          </div>
        </div>
        <?php }  ?>
      </form>
    </div>
  </div>
</div>