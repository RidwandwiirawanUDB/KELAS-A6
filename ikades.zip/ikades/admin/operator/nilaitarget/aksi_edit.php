<?php 
	//untuk  memulai menggunakan sassion
	session_start();
	//untuk mengecek apakah session 'username' dan 'password' sudah ada atau belum, session tersebut tercipta jika operator sudah login
	//jadi jika admin blm login maka tidak dapat mengakses file ini
	if (empty($_SESSION['usernameadmin']) AND empty ($_SESSION['passadmin'])) {
		echo "<center>Untuk mengakses modul anda harus login<br>";
		echo "<a href=../../../login.php><b>LOGIN</b></a></center>";
	}else{
		//untuk memasukkan file config.php dan file koneksi.php
		include "../../../lib/koneksi.php";
		//untuk menangkap variabel nama produk yang dikirim oleh form tamnbah.php

		$id=$_POST['id'];
		$Penalaran = $_POST['Penalaran'];
		$Verbalisasi = $_POST['Verbalisasi'];
		$Sistematika = $_POST['Sistematika'];
		$Logika = $_POST['Logika'];
		$Fleksibilitas = $_POST['Fleksibilitas'];
		$Imajinasi = $_POST['Imajinasi'];
        $Antisipasi = $_POST['Antisipasi'];
        $Potensi = $_POST['Potensi'];
		$Tanggungjawab = $_POST['Tanggungjawab'];
        $Vitalitas = $_POST['Vitalitas'];

        $queryEdit = mysqli_query($con,"UPDATE kriteria SET Penalaran='$Penalaran',Verbalisasi='$Verbalisasi',Sistematika='$Sistematika',Logika='$Logika',Fleksibilitas='$Fleksibilitas',Imajinasi='$Imajinasi',Antisipasi='$Antisipasi',Potensi='$Potensi',Tanggungjawab='$Tanggungjawab',Vitalitas='$Vitalitas' WHERE id='$id'");
            if ($queryEdit) {
                echo "<script>alert ('Nilai Target berhasil di edit'); window.location = '../../dashboard.php?module=target';</script>";
            //jika query gagal maka akan tampil alert dan halaman akan kembali ke tambah produk
            }else{
                echo "<script>alert ('Nilai Target gagal di edit'); window.location = '../../dashboard.php?module=target&id='+'$id';</script>";
            }
        }
			
 ?>
