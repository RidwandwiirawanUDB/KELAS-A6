<!-- Author: Khihady Sucahyo -->

<h5 align="center">= Tabel Profile alternatif =</h5>
<table class="striped centered">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Attitude</th>
        <th>Penampilan</th>
        <th>Keaktifan</th>
        <th>Ekonomi</th>
      </tr>
    </thead>
    <tbody>

    <?php while($alternatif=mysqli_fetch_array($query)){ ?>
      <?php $datas[] = $alternatif; ?>
      <tr>
        <td><?=$i?></td>
        <td><?=$alternatif['nama']?></td>
        <td><?=$alternatif['attitude']?></td>
        <td><?=$alternatif['penampilan']?></td>
        <td><?=$alternatif['keaktifan']?></td>
        <td><?=$alternatif['ekonomi']?></td>
      </tr>
      <?php $i++ ?>
    <?php } $i=1;?>

    <tr class="red-text" style="font-weight:bold;">
      <td> </td>
      <td> = Kriteria yang diinginkan =</td>
      <?php $k=mysqli_fetch_array($query_kriteria); ?>
      <td><?=$k1=$k['attitude']?></td>
      <td><?=$k2=$k['penampilan']?></td>
      <td><?=$k3=$k['keaktifan']?></td>
      <td><?=$k4=$k['ekonomi']?></td>
    </tr>

    </tbody>
</table>
