<div class="content-page">
<!-- Start content -->
<div class="content">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title-box">
                        <h4 class="page-title">Manajemen Nilai Factor</h4>
                        <ol class="breadcrumb p-0 m-0">
                            <li>
                                <a href="#">iKaDes</a>
                            </li>
                            <li class="active">
                                Nilai Factor
                        </ol>
                        <div class="clearfix"></div>
                    </div>
            </div>
        </div> 
        <!-- end row -->
        <div class="row">
<div class="col-md-12 col-sm-12 col-xs-12 card-box">
  <div class="x_panel">
    <div class="x_title">
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
      <br /> 
      <form data-parsley-validate class="form-horizontal form-label-left" action="operator/percentage/aksi_edit.php" method="post">
        <?php 
            include "../lib/koneksi.php";
            $no = 1;
            $kueriR = mysqli_query($con,"SELECT percentage FROM core_factor limit 1");
            $kat=mysqli_fetch_array($kueriR);
            $second = 100 - $kat['percentage'];
        ?>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="nama_operator">Persentase Core Factor (%)<span class="required">*</span>
          </label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Penalaran" name="core" required="required" class="form-control col-md-7 col-xs-12" value="<?php echo $kat['percentage']; ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="nama_operator">Persentase Secondary Factor (%)<span class="required">*</span>
          </label> 
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="Penalaran" name="second" readonly class="form-control col-md-7 col-xs-12" value="<?php echo $second ; ?>">
          </div>
        </div>
        
        <div class="ln_solid"></div>
        <div class="form-group">
          <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
            <button class="btn btn-primary" type="button">Cancel</button>
            <button type="submit" class="btn btn-success">Submit</button>
          </div>
        </div>

      </form>
    </div>
  </div>
</div>