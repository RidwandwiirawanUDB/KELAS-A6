<?php 
	//untuk  memulai menggunakan sassion
	session_start();
	
	//untuk mengecek apakah session 'username' dan 'password' sudah ada atau belum, session tersebut tercipta jika operator sudah login
	//jadi jika admin blm login maka tidak dapat mengakses file ini
	if (empty($_SESSION['usernameadmin']) AND empty ($_SESSION['passadmin'])) {
		echo "<center>Untuk mengakses modul anda harus login<br>";
		echo "<a href=../../../login.php><b>LOGIN</b></a></center>";
	}else{
		include "../../../lib/koneksi.php";

		//untuk menangkap variabel
		$core=$_POST['core'];

        $queryEdit = mysqli_query($con,"UPDATE core_factor SET percentage='$core'");
            if ($queryEdit) {
                echo "<script>alert ('Nilai Factor berhasil di edit'); window.location = '../../dashboard.php?module=percentage';</script>";

            }else{
                echo "<script>alert ('Nilai Factor gagal di edit'); window.location = '../../dashboard.php?module=percentage;</script>";
            }
        }
			
 ?>
