<?php
$i=1;
mysqli_query($koneksi,"delete from ranking");
foreach($datas as $data) {
  mysqli_query($koneksi, "insert into ranking values(".$i.",'".$data['nama']."',".$na[$i].");");
  $i++;
}
?>

<!-- Tabel Bobot -->
<hr><br>
<h5 align="left">&nbsp&nbsp&nbspPerangkingan Seleksi Kepala Desa Sukoharjo</h5>
<div class="col s6">
  <table class="table m-0 table-colored table-info">

      <thead>
        <tr>
          <th>Peringkat</th>
          <th>Nama</th>
          <th>Nilai Akhir</th>
        </tr>
      </thead>

      <tbody>

      <?php
      $i=1;
      $qRank = mysqli_query($koneksi,"select * from ranking order by nilai_akhir desc");
      while($rank=mysqli_fetch_array($qRank)){ ?>
      <tr>
        <td><?=$i?></td>
        <td><?=$rank['nama']?></td>
        <td><?=$rank['nilai_akhir']?></td>
      </tr>
      <?php $i++; } ?>
      </tbody>

  </table>
</div>
<!-- End Tabel Bobot -->
