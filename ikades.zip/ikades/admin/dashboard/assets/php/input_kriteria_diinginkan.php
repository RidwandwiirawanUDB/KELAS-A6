<div class="col s4">
    <div class="card">
      <div class="card-content">
        <div class="card-action">
          <table class="">
              <thead>
                <tr>
                  <th colspan="2">Kriteria yang diinginkan</th>
                </tr>
              </thead>
          </table>
            <input type="text" required name="kt_attitude" placeholder="Kriteria attitude">
            <input type="text" required name="kt_penampilan" placeholder="Kriteria penampilam">
            <input type="text" required name="kt_keaktifan" placeholder="Kriteria keaktifan">
            <input type="text" required name="kt_ekonomi" placeholder="Kriteria ekonomi">
        </div>
      </div>
    </div>
</div>
