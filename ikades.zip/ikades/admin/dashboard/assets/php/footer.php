<footer class="page-footer teal white-text">
  <div class="footer-copyright black darken-4">
    <div class="container">
      <div class="row">
        <div class="col s12 m11 11 white-text">
            <!-- <i class="material-icons">copyright</i> -->
            <strong>e-Jodoh &copy 2017</strong>
        </div>
      </div>
    </div>
  </div>
</footer>
<!-- <script src="materialize/js/jquery-3.1.1.min.js"></script> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="assets/materialize/js/materialize.min.js"></script>
</body>
</html>
