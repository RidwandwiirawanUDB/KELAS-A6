<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Dashboard Siswa</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Cavalry</a>
                                        </li>
                                        <li>
                                            <a href="#">Dashboard</a>
                                        </li>
                                        <li class="active">
                                            Dashboard
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <!-- end row -->

<?php
$jml_gebetan = $_POST['jml_gebetan'];
?>

      <main>
        <div class="container">
          <div class="row">
          <div class="col s4">
          <div class="col-md-6">

<div class="demo-box">
    <div class="card">
      <div class="card-content">
        <!-- <div class="card-title center-align indigo-text"><strong>Biodata Peserta</strong></div> -->
        <div class="table-responsive">
              <input type="hidden" name="jml_gebetan" value="<?=$jml_gebetan?>">
              <table class="table m-0 table-colored table-success">
                  <thead>
                    <tr>
                      <th colspan="2">Keterangan</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>Sangat Buruk</td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>Buruk</td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>Sedang</td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>Baik</td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>Sangat Baik</td>
                    </tr>
                  </tbody>
              </table>
        </div>
      </div>
    </div>
</div>
<div class="container">
          <div class="row">
          <div class="col s4">
          <div class="col-md-12">
<div class="col s4">
    <div class="card">
      <div class="card-content">
        <div class="card-action">
              <table class="table m-0 table-colored table-info">
                  <thead>
                    <tr>
                      <th colspan="2">Core Factor</th>
                    </tr>
                  </thead>
                  <tbody>
                  <form class="form-horizontal" role="form" method="post" action="admin/dashboard/proses_data.php">
                    <tr>
                      <td>
                        <input data-parsley-multiple="groups" data-parsley-mincheck="2" type="checkbox" name="cf_attitude" value="1" id="attitude">
                        <label for="attitude">Attitude</label>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input  type="checkbox" name="cf_penampilan" value="1" id="penampilan">
                        <label for="penampilan">Penampilan</label>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input  type="checkbox" name="cf_keaktifan" value="1" id="keaktifan">
                        <label for="keaktifan">Keaktifan</label>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <input type="checkbox" name="cf_ekonomi" value="1" id="ekonomi">
                        <label for="ekonomi">Ekonomi</label>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <label for="cf_percentage">Percentage %</label>
                        <input required type="text" name="cf_percentage" id="cf_percentage">
                      </td>
                    </tr>
                  </tbody>
              </table>
        </div>
      </div>
    </div>
</div>
<div class="container">
          <div class="row">
          <div class="col s4">
          <div class="col-md-12">
<div class="col s4">
    <div class="card">
      <div class="card-content">
        <div class="card-action">
          <table class="table m-0 table-colored table-purple table-hover">
              <thead>
                <tr>
                  <th colspan="2">Kriteria yang diinginkan</th>
                </tr>
              </thead>
          </table>
            <input type="text" class="form-control" required name="kt_attitude" placeholder="Kriteria attitude">
            <input type="text" class="form-control" required name="kt_penampilan" placeholder="Kriteria penampilam">
            <input type="text" class="form-control" required name="kt_keaktifan" placeholder="Kriteria keaktifan">
            <input type="text" class="form-control" required name="kt_ekonomi" placeholder="Kriteria ekonomi">
        </div>
      </div>
    </div>
</div>

</div>
</div>
</div>
</div>
<div class="container">
          <div class="row">
          <div class="col s4">
          <div class="col-md-12">
          <!-- END KTEREANGAN -->
          <div class="row">
            <div class="col s12">
                <div class="card">
                  <div class="card-content">
                    <!-- <div class="card-title center-align indigo-text"><strong>Biodata Peserta</strong></div> -->
                    <div class="card-action">
                          <input type="hidden" name="jml_gebetan" value="<?=$jml_gebetan?>">
                          <table class="table m-0 table-colored table-danger">
                              <thead>
                                <tr>
                                  <th>No</th>
                                  <th>Nama</th>
                                  <th>Attitude</th>
                                  <th>Penampilan</th>
                                  <th>Keaktifan</th>
                                  <th>Ekonomi</th>
                                </tr>
                              </thead>
                              <tbody>
                              <?php for ($i=1; $i<=$jml_gebetan; $i++) { ?>
                                  <tr>
                                    <td><?=$i?></td>
                                    <td><input class="form-control" required type="text" class="validate" name="nama<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="attitude<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="penampilan<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="keaktifan<?=$i?>" value=""></td>
                                    <td><input class="form-control" required type="text" class="validate" name="ekonomi<?=$i?>" value=""></td>
                                  </tr>
                              <?php } ?>
                              </tbody>
                          </table>

                          <div class="row">
                              <div class="input-field offset-s12">
                                <button  type="submit" name="proses" class="btn btn-primary right">
                                  Proses
                                </button>
                              </div>
                          </div>

                      </form>
                    </div>
                  </div>
                </div>

            </div>
          </div>
        </div>
                              </div>
      </main>

