<?php
  include 'lib/koneksi.php';
  // include 'assets/php/destroy.php';
?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Dashboard Siswa</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">Cavalry</a>
                                        </li>
                                        <li>
                                            <a href="#">Dashboard</a>
                                        </li>
                                        <li class="active">
                                            Dashboard
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <!-- end row -->
<div class="row">
<main class="container valign-wrapper">
      <div class="row"> <!-- actually the issue is here - row is not expanded to cover 100% width -->
          <div class="col s12">
            <div class="text-center card-box">
              <h2 style="color: rgb(4, 51, 83);">i-KaDes</h2>
              <span class="white-text">
                i KaDes adalah aplikasi yang diperuntukkan untuk membantu user dalam melakukan perangkingan terhadap calon kepala desa sehingga memudahkan dalam pengambilan keputusan. 
                Kepala Desa adalah pemimpin dari pemerintahan di tingkat desa di Negara Indonesia. Masa jabatan 
                Kepala Desa adalah 6 (enam) tahun, dan dapat diperpanjang lagi untuk satu kali masa jabatan berikutnya. 
                Kepala desa tidak bertanggung jawab kepada Camat, namun hanya dikoordinasikan saja oleh Camat. Kebingungan warga untuk memilih 
                kepala Desa ibarat memilih kucing dalam karung Kita bingung memilih pemimpin yang bisa menjaga amanah masyarakat. 
                Perkembangan kemajuan tekhnologi khususnya informasi yang sangat pesat membuat perubahan di berbagai bidang, maka dari itu penulis
                berusaha membuat sebuah sistem pengambilan keputusan Untuk membatu warga masyarakat desa dalam memilih suatu pemimpin 
                desa atau kepala desa sesuai dengan syarat dan kriteria-kriteria yang ditentukan undang undang serta berdasarkan Peraturan 
                Pemerintah Republik Indonesia Nomor 72 Tahun 2005 Tentang pemilihan kepala Desa.. untuk merancang sistem pendukung keputusan 
                untuk membantu masyarakat dalam Pemilihan Pilkades dengan judul sistem pendukung keputusan penyelenggaran pemilihan 
                Kepala Desa Pekraman Beraban berbasisi Dekstop Menggunakan Metode GAP, selain itu GAP juga dapat menyeleksi alternative
                terbaik dari sejumlah alternatif yang ada karena adanya proses perankingan setelah menentukan nilai bobot untuk setiap atribut. 
                Dengan adanya aplikasi ini diharapkan dapat mengurangi permasalahan yang ada.

              </span>
              <div class="row">
								<div class="page-title-box">
              <form class="form-horizontal" role="form" method="post" action="dashboard.php?module=inputdata">
              
              <div class="col-md-6">
              <input required type="text" id="state-success" class="form-control" name="jml_gebetan" placeholder="Masukkan Jumlah Alternatif" value="">
              </div>
                  <div class="form-group">
                    <button  type="submit" class="btn btn-primary right">
                      Proses
                    </button>
                  </div>
              </div>
              </div>
              </div>
              </div>
            </form>
            </div>
</div>
</div>
          </div>
      </div>
    </main>