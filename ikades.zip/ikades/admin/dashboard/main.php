<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <div class="row">
							<div class="col-xs-12">
								<div class="page-title-box">
                                    <h4 class="page-title">Dashboard Admin</h4>
                                    <ol class="breadcrumb p-0 m-0">
                                        <li>
                                            <a href="#">iKaDes</a>
                                        </li>
                                        <li class="active">
                                            Main
                                        </li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
							</div>
						</div>
                        <!-- end row -->


<div class="row"> 
    <div class="col-sm-12">
        <div class="card-box">
            <div class="row">
                <div class="text-justify">
                <div class="col-lg-4">
                    <h4 class="m-t-0 header-title"><b>Tentang Seleksi berbasis sistem web</b></h4>
                    <img src="upload/images/6.jpg" alt="image" class="img-responsive"/><br>
                    <p>
                    Sistem pendukung keputusan seleksi pemilihan calon kepala desa berbasis web dapat
                    membantu mempermudah admin serta user dalam menyeleksi calon kepala desa. Sistem ini
                    mempunyai dua tipe user, yaitu administrator dan user operator. Administator mempunyai menu
                    untuk menambah dan mengedit sistem. Sedangkan untuk user operator mempunyai menu cara
                    penggunaan sistem, syarat syarat menjadi calon kepala desa, informasi tentang pemilihan kepala
                    desa dan cara pendaftaran. Sistem ini merupakan aplikasi berbasis web sehingga dapat diakses
                    secara offline dan online 
                    </p>
                </div>

                <div class="col-lg-8 m-t-sm-50">
                    <h4 class="m-t-0 header-title"><b>Kelebihan Sistem</b></h4>
                    <p>
                    Kepala Desa adalah pemimpin dari
                    pemerintahan di tingkat desa di
                    Negara Indonesia. Masa jabatan
                    Kepala Desa adalah 6 (enam) tahun,
                    dan dapat diperpanjang lagi untuk
                    satu kali masa jabatan berikutnya.
                    Kepala Desa tidak bertanggung
                    jawab kepada Camat, namun hanya
                    dikoordinasikan saja oleh Camat. 
                    </p>
                    <p>
                    Kebingungan warga untuk memilih
                    kepala desa ibarat memilih kucing
                    dalam karung Kita bingung melihat
                    pemimpin yang tidak amanah. Kita
                    terheran-heran menyaksikan mereka
                    yang lebih memprioritaskan
                    kepentingan diri dan keluarganya
                    daripada orang-orang yang
                    dipimpinnya. Seringkali kita terkejut
                    mengetahui orang-orang yang
                    seharusnya menjadi panutan malah
                    melakukan perbuatan yang
                    melanggar hukum maupun norma
                    susila yang anehnya di anggap
                    wajar.</p>
                    <p>
                    Perkembangan kemajuan tekhnologi
                    khususnya informasi yang sangat
                    pesat membuat perubahan di
                    berbagai bidang, maka dari itu
                    penulis berusaha membuat sebuah
                    sistem pengambilan keputusan untuk
                    membatu pemerintah daerah untuk
                    menyeleksi kepala desa serta warga
                    masyarakat desa dalam memilih
                    suatu pemimpin desa atau kepala
                    desa sesuai dengan syarat dan
                    kriteria-kriteria yang ditentukan
                    undang undang serta berdasarkan
                    Peraturan Pemerintah Republik
                    Indonesia Nomor 72 Tahun 2005
                    Tentang pemilihan kepala Desa.
                    Berdasarkan latar belakang diatas,
                    diusulkan untuk merancang sistem
                    pendukung keputusan untuk
                    membantu pelaksanaan pilkades
                    dengan judul sistem pendukung
                    keputusan penyelenggaran seleksi
                    kepala desa berbasisi web.
                    </p>

                    <div class="row">
                        <div class="col-md-3">
                            <div class="thumbnail">
                                <img src="../upload/images/1.jpg" class="img-responsive" alt="image">
                                <div class="caption">
                                    <h3>Mudah</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="thumbnail">
                                <img src="../upload/images/2.jpg" class="img-responsive" alt="image">
                                <div class="caption">
                                    <h3>Akurat</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="thumbnail">
                                <img src="../upload/images/3.jpg" class="img-responsive" alt="image">
                                <div class="caption">
                                    <h3>Cepat</h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="thumbnail">
                                <img src="../upload/images/4.jpg" class="img-responsive" alt="image">
                                <div class="caption">
                                    <h3>Fungsional</h3>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div> <!-- end row -->
</div>