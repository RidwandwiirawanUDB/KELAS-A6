<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "ikades";

$operator_url = "http://localhost/ikades/";
$admin_url = "http://localhost/ikades/admin";

//koneksi ke database
$con=mysqli_connect($server,$username,$password) or die("Koneksi Gagal");
mysqli_select_db($con,$database) or die("Database tidak bisa dibuka");

$koneksi=mysqli_connect($server,$username,$password) or die("Koneksi Gagal!");
mysqli_select_db($koneksi,$database) or die("Database gabisa dibuka!");

?>