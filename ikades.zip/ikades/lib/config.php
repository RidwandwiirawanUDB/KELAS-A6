<?php
	$base_url = "http://localhost/osmaga-open/";
	$admin_url = "http://localhost/osmaga-open/admin/";
	$mpk_url = "http://localhost/osmaga-open/mpk/";
	$pembina_url = "http://localhost/osmaga-open/pembina/";
?>